"""
validators.py — Input Validation Module
========================================
Provides validation functions for all user inputs.
"""

import re
from datetime import datetime


def validate_roll_no(roll_no):
    if not roll_no or not roll_no.strip():
        return False, "Roll number cannot be empty!"
    roll_no = roll_no.strip()
    if len(roll_no) > 20:
        return False, "Roll number cannot exceed 20 characters!"
    if not re.match(r'^[A-Za-z0-9\-/]+$', roll_no):
        return False, "Roll number can only contain letters, numbers, hyphens, and slashes!"
    return True, None


def validate_name(name):
    if not name or not name.strip():
        return False, "Student name cannot be empty!"
    name = name.strip()
    if len(name) < 2:
        return False, "Name must be at least 2 characters long!"
    if len(name) > 100:
        return False, "Name cannot exceed 100 characters!"
    if not re.match(r'^[A-Za-z\s.]+$', name):
        return False, "Name can only contain letters, spaces, and periods!"
    return True, None


def validate_branch(branch):
    if not branch or not branch.strip():
        return False, "Branch/Class cannot be empty!"
    branch = branch.strip()
    if len(branch) > 50:
        return False, "Branch name cannot exceed 50 characters!"
    if not re.match(r'^[A-Za-z0-9\s\-]+$', branch):
        return False, "Branch can only contain letters, numbers, spaces, and hyphens!"
    return True, None


def validate_date(date_str):
    if not date_str or not date_str.strip():
        return False, "Date cannot be empty!"
    date_str = date_str.strip()
    try:
        parsed_date = datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        return False, "Invalid date format! Use YYYY-MM-DD (e.g., 2026-04-23)"
    if parsed_date.date() > datetime.now().date():
        return False, "Cannot mark attendance for a future date!"
    return True, None


def validate_teacher_id(teacher_id):
    if not teacher_id or not teacher_id.strip():
        return False, "Teacher ID cannot be empty!"
    teacher_id = teacher_id.strip()
    if len(teacher_id) < 3:
        return False, "Teacher ID must be at least 3 characters!"
    if not re.match(r'^[A-Za-z0-9\-]+$', teacher_id):
        return False, "Teacher ID can only contain letters, numbers, and hyphens!"
    return True, None


def validate_password(password):
    if not password or not password.strip():
        return False, "Password cannot be empty!"
    if len(password) < 4:
        return False, "Password must be at least 4 characters!"
    return True, None

"""
╔══════════════════════════════════════════════════════════════╗
║        STUDENT ATTENDANCE MANAGEMENT SYSTEM                  ║
║        ─────────────────────────────────────                 ║
║        BTECH Semester 2 — College Project                     ║
║                                                              ║
║        Built with: Python 3 | CustomTkinter | SQLite          ║
║        Features:  Role-Based Login (Teacher / Student)        ║
║                   Subject-Wise Attendance                     ║
╚══════════════════════════════════════════════════════════════╝

main.py — Application Entry Point
===================================
Starts the app with a login page. After authentication,
loads the appropriate role-based dashboard.

How to run:
    pip install -r requirements.txt
    python main.py

Subject-Wise Faculty Logins:
    PY-TEACH  / python123    - Python       (Snehal Khajurgi)
    CAL-TEACH / calculus123   - Calculus     (Shital Sobale)
    AEM-TEACH / aem123        - AEM          (Kalpesh Joshi)
    DA-TEACH  / data123       - Data Analysis (Vinod Kimbahune)
    SRM-TEACH / srm123        - SRM-2        (Jyoti Yadav)

Student Login:
    Roll Number + Full Name (must match records)
"""

import tkinter as tk
import customtkinter as ctk
from database.db_manager import initialize_database
from gui.login import LoginPage
from gui.app import AttendanceApp
from gui.styles import SIZES

# Set appearance
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


class MainApplication:
    """Root application controller managing login/dashboard transitions."""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Student Attendance Management System — VIT Pune")
        self.root.geometry(f"{SIZES['window_width']}x{SIZES['window_height']}")
        self.root.minsize(1000, 650)
        self.root.configure(bg="#0A0A15")

        try:
            self.root.iconbitmap(default="")
        except Exception:
            pass

        # Center window on screen
        self.root.update_idletasks()
        w = SIZES['window_width']
        h = SIZES['window_height']
        x = (self.root.winfo_screenwidth() // 2) - (w // 2)
        y = (self.root.winfo_screenheight() // 2) - (h // 2)
        self.root.geometry(f"{w}x{h}+{x}+{y}")

        self.current_app = None
        self._show_login()

    def _show_login(self):
        """Show the login page."""
        for w in self.root.winfo_children():
            w.destroy()

        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        # Reset grid config from app layout
        try:
            self.root.grid_columnconfigure(1, weight=0)
        except Exception:
            pass

        login = LoginPage(self.root, self._on_login)
        login.pack(fill="both", expand=True)

    def _on_login(self, role, user_info):
        """Handle successful login — transition to dashboard."""
        self.current_app = AttendanceApp(
            self.root, role, user_info, self._on_logout
        )

    def _on_logout(self):
        """Handle logout — go back to login page."""
        self.current_app = None
        self._show_login()

    def run(self):
        """Start the application."""
        self.root.mainloop()


def main():
    print("[*] Initializing database...")
    initialize_database()
    print("[OK] Database ready!")
    print("[*] Launching application...")
    print("[OK] Application running!")
    print()
    print("Subject-Wise Faculty Logins:")
    print("  PY-TEACH  / python123    >> Python        (Snehal Khajurgi)")
    print("  CAL-TEACH / calculus123   >> Calculus      (Shital Sobale)")
    print("  AEM-TEACH / aem123        >> AEM           (Kalpesh Joshi)")
    print("  DA-TEACH  / data123       >> Data Analysis  (Vinod Kimbahune)")
    print("  SRM-TEACH / srm123        >> SRM-2         (Jyoti Yadav)")
    print()
    print("Student Login: Roll Number + Full Name")
    print()

    app = MainApplication()
    app.run()

    print("[*] Application closed. Goodbye!")


if __name__ == "__main__":
    main()

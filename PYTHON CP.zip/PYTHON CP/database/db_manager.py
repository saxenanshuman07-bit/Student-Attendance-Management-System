"""
db_manager.py — Database Manager Module
========================================
Handles all SQLite database operations including:
- Creating tables (students, attendance, teachers, subjects)
- CRUD operations for students
- Recording and querying attendance
- Teacher authentication (subject-wise)
- Subject-wise attendance
"""

import sqlite3
import os
import hashlib
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "attendance.db")


def get_connection():
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def initialize_database():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            roll_no     TEXT    NOT NULL UNIQUE,
            name        TEXT    NOT NULL,
            branch      TEXT    NOT NULL,
            created_at  TEXT    DEFAULT (datetime('now', 'localtime'))
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS subjects (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            name    TEXT    NOT NULL UNIQUE
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id  INTEGER NOT NULL,
            date        TEXT    NOT NULL,
            status      TEXT    NOT NULL CHECK(status IN ('Present', 'Absent')),
            subject_id  INTEGER,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL,
            UNIQUE(student_id, date, subject_id)
        )
    """)

    # Teachers table with subject_id for subject-specific login
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS teachers (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_id  TEXT    NOT NULL UNIQUE,
            name        TEXT    NOT NULL,
            password    TEXT    NOT NULL,
            subject_id  INTEGER,
            created_at  TEXT    DEFAULT (datetime('now', 'localtime')),
            FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL
        )
    """)

    # Add subject_id column to teachers if it doesn't exist (migration for existing DB)
    try:
        cursor.execute("ALTER TABLE teachers ADD COLUMN subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL")
    except sqlite3.OperationalError:
        pass  # Column already exists

    # ── Insert the 5 required subjects ──
    required_subjects = ["Python", "Calculus", "AEM", "Data Analysis", "SRM-2"]
    for subj in required_subjects:
        cursor.execute("INSERT OR IGNORE INTO subjects (name) VALUES (?)", (subj,))
    conn.commit()

    # ── Build subject ID map ──
    cursor.execute("SELECT id, name FROM subjects")
    subj_map = {name: sid for sid, name in cursor.fetchall()}

    # ── Subject-specific teacher logins ──
    # Each subject has a unique teacher login ID
    teacher_logins = [
        ("PY-TEACH",   "Snehal Khajurgi",         "python123",       "Python"),
        ("CAL-TEACH",  "Shital Sobale",           "calculus123",     "Calculus"),
        ("AEM-TEACH",  "Kalpesh Joshi",           "aem123",          "AEM"),
        ("DA-TEACH",   "Vinod Kimbahune",         "data123",         "Data Analysis"),
        ("SRM-TEACH",  "Jyoti Yadav",             "srm123",          "SRM-2"),
    ]

    for tid, tname, tpwd, tsubj in teacher_logins:
        cursor.execute("SELECT COUNT(*) FROM teachers WHERE teacher_id = ?", (tid,))
        if cursor.fetchone()[0] == 0:
            pwd_hash = hash_password(tpwd)
            sid = subj_map.get(tsubj)
            cursor.execute(
                "INSERT INTO teachers (teacher_id, name, password, subject_id) VALUES (?, ?, ?, ?)",
                (tid, tname, pwd_hash, sid)
            )

    # Update existing TEACH-001 to have Python subject if it exists and has no subject
    cursor.execute("SELECT id, subject_id FROM teachers WHERE teacher_id = 'TEACH-001'")
    old_teacher = cursor.fetchone()
    if old_teacher and old_teacher[1] is None:
        py_sid = subj_map.get("Python")
        if py_sid:
            cursor.execute("UPDATE teachers SET subject_id = ? WHERE teacher_id = 'TEACH-001'", (py_sid,))

    conn.commit()
    conn.close()


# ══════════════════════════════════════════════════════════
#  TEACHER AUTH
# ══════════════════════════════════════════════════════════

def authenticate_teacher(teacher_id, password):
    """Authenticate teacher and return (id, teacher_id, name, subject_id, subject_name)."""
    conn = get_connection()
    cursor = conn.cursor()
    pwd_hash = hash_password(password)
    cursor.execute(
        """SELECT t.id, t.teacher_id, t.name, t.subject_id, COALESCE(s.name, 'General')
           FROM teachers t
           LEFT JOIN subjects s ON t.subject_id = s.id
           WHERE t.teacher_id = ? AND t.password = ?""",
        (teacher_id.strip(), pwd_hash)
    )
    teacher = cursor.fetchone()
    conn.close()
    return teacher


def authenticate_student(roll_no, name):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, roll_no, name, branch FROM students WHERE roll_no = ? AND LOWER(name) = LOWER(?)",
        (roll_no.strip(), name.strip())
    )
    student = cursor.fetchone()
    conn.close()
    return student


# ══════════════════════════════════════════════════════════
#  STUDENT OPERATIONS
# ══════════════════════════════════════════════════════════

def add_student(roll_no, name, branch):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO students (roll_no, name, branch) VALUES (?, ?, ?)",
            (roll_no.strip(), name.strip(), branch.strip())
        )
        conn.commit()
        return True, f"Student '{name}' added successfully!"
    except sqlite3.IntegrityError:
        return False, f"Roll number '{roll_no}' already exists!"
    except Exception as e:
        return False, f"Error: {str(e)}"
    finally:
        conn.close()


def get_all_students():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, roll_no, name, branch, created_at FROM students ORDER BY roll_no")
    students = cursor.fetchall()
    conn.close()
    return students


def get_students_by_branch(branch):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, roll_no, name, branch FROM students WHERE branch = ? ORDER BY roll_no",
        (branch,)
    )
    students = cursor.fetchall()
    conn.close()
    return students


def get_student_by_roll_no(roll_no):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, roll_no, name, branch FROM students WHERE roll_no = ?",
        (roll_no.strip(),)
    )
    student = cursor.fetchone()
    conn.close()
    return student


def update_student(student_id, roll_no, name, branch):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE students SET roll_no=?, name=?, branch=? WHERE id=?",
            (roll_no.strip(), name.strip(), branch.strip(), student_id)
        )
        conn.commit()
        return True, "Student updated successfully!"
    except sqlite3.IntegrityError:
        return False, f"Roll number '{roll_no}' already exists!"
    except Exception as e:
        return False, f"Error: {str(e)}"
    finally:
        conn.close()


def delete_student(student_id):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM students WHERE id = ?", (student_id,))
        conn.commit()
        return True, "Student deleted successfully!"
    except Exception as e:
        return False, f"Error: {str(e)}"
    finally:
        conn.close()


def get_all_branches():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT branch FROM students ORDER BY branch")
    branches = [row[0] for row in cursor.fetchall()]
    conn.close()
    return branches


def search_students(query):
    conn = get_connection()
    cursor = conn.cursor()
    like_query = f"%{query}%"
    cursor.execute(
        """SELECT id, roll_no, name, branch, created_at FROM students
           WHERE roll_no LIKE ? OR name LIKE ? OR branch LIKE ?
           ORDER BY roll_no""",
        (like_query, like_query, like_query)
    )
    students = cursor.fetchall()
    conn.close()
    return students


# ══════════════════════════════════════════════════════════
#  SUBJECT OPERATIONS
# ══════════════════════════════════════════════════════════

def get_all_subjects():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name FROM subjects ORDER BY name")
    subjects = cursor.fetchall()
    conn.close()
    return subjects


def get_subject_by_id(subject_id):
    """Return (id, name) for a given subject_id."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name FROM subjects WHERE id = ?", (subject_id,))
    subject = cursor.fetchone()
    conn.close()
    return subject


def add_subject(name):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO subjects (name) VALUES (?)", (name.strip(),))
        conn.commit()
        return True, f"Subject '{name}' added!"
    except sqlite3.IntegrityError:
        return False, f"Subject '{name}' already exists!"
    finally:
        conn.close()


# ══════════════════════════════════════════════════════════
#  ATTENDANCE OPERATIONS
# ══════════════════════════════════════════════════════════

def mark_attendance(student_id, date, status, subject_id=None):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            """INSERT OR REPLACE INTO attendance (student_id, date, status, subject_id)
               VALUES (?, ?, ?, ?)""",
            (student_id, date, status, subject_id)
        )
        conn.commit()
        return True, "Attendance marked successfully!"
    except Exception as e:
        return False, f"Error: {str(e)}"
    finally:
        conn.close()


def mark_bulk_attendance(records):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.executemany(
            """INSERT OR REPLACE INTO attendance (student_id, date, status, subject_id)
               VALUES (?, ?, ?, ?)""",
            records
        )
        conn.commit()
        return True, f"Attendance marked for {len(records)} students!"
    except Exception as e:
        return False, f"Error: {str(e)}"
    finally:
        conn.close()


def get_all_attendance_records(subject_id=None):
    """Get all attendance records, optionally filtered by subject_id."""
    conn = get_connection()
    cursor = conn.cursor()
    if subject_id:
        cursor.execute("""
            SELECT s.roll_no, s.name, s.branch, a.date, a.status,
                   COALESCE(sub.name, 'General') as subject
            FROM attendance a
            JOIN students s ON a.student_id = s.id
            LEFT JOIN subjects sub ON a.subject_id = sub.id
            WHERE a.subject_id = ?
            ORDER BY a.date DESC, s.roll_no
        """, (subject_id,))
    else:
        cursor.execute("""
            SELECT s.roll_no, s.name, s.branch, a.date, a.status,
                   COALESCE(sub.name, 'General') as subject
            FROM attendance a
            JOIN students s ON a.student_id = s.id
            LEFT JOIN subjects sub ON a.subject_id = sub.id
            ORDER BY a.date DESC, s.roll_no
        """)
    records = cursor.fetchall()
    conn.close()
    return records


def get_attendance_by_roll_no(roll_no):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT a.date, a.status, COALESCE(sub.name, 'General') as subject
        FROM attendance a
        JOIN students s ON a.student_id = s.id
        LEFT JOIN subjects sub ON a.subject_id = sub.id
        WHERE s.roll_no = ?
        ORDER BY a.date DESC
    """, (roll_no.strip(),))
    records = cursor.fetchall()
    conn.close()
    return records


def get_attendance_percentage(roll_no):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT
            COUNT(*) as total,
            SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present,
            SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) as absent
        FROM attendance a
        JOIN students s ON a.student_id = s.id
        WHERE s.roll_no = ?
    """, (roll_no.strip(),))
    result = cursor.fetchone()
    conn.close()
    if result[0] == 0:
        return None
    total = result[0]
    present = result[1] or 0
    absent = result[2] or 0
    percentage = round((present / total) * 100, 2) if total > 0 else 0
    return {
        "total_days": total, "present_days": present,
        "absent_days": absent, "percentage": percentage
    }


def get_subject_wise_attendance(roll_no):
    """Get attendance breakdown for each subject for a given student."""
    conn = get_connection()
    cursor = conn.cursor()

    # Get all 5 subjects
    cursor.execute("SELECT id, name FROM subjects ORDER BY name")
    all_subjects = cursor.fetchall()

    results = []
    for subj_id, subj_name in all_subjects:
        cursor.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present,
                SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) as absent
            FROM attendance a
            JOIN students s ON a.student_id = s.id
            WHERE s.roll_no = ? AND a.subject_id = ?
        """, (roll_no.strip(), subj_id))
        row = cursor.fetchone()
        total = row[0] or 0
        present = row[1] or 0
        absent = row[2] or 0
        pct = round((present / total) * 100, 2) if total > 0 else 0
        results.append({
            "subject": subj_name, "total": total,
            "present": present, "absent": absent, "percentage": pct
        })

    conn.close()
    return results


def get_all_students_percentage(subject_id=None):
    """Get attendance percentage for all students, optionally filtered by subject."""
    conn = get_connection()
    cursor = conn.cursor()
    if subject_id:
        cursor.execute("""
            SELECT s.roll_no, s.name, s.branch,
                COUNT(a.id) as total,
                SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present,
                SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) as absent
            FROM students s
            LEFT JOIN attendance a ON s.id = a.student_id AND a.subject_id = ?
            GROUP BY s.id ORDER BY s.roll_no
        """, (subject_id,))
    else:
        cursor.execute("""
            SELECT s.roll_no, s.name, s.branch,
                COUNT(a.id) as total,
                SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present,
                SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) as absent
            FROM students s
            LEFT JOIN attendance a ON s.id = a.student_id
            GROUP BY s.id ORDER BY s.roll_no
        """)
    results = []
    for row in cursor.fetchall():
        total = row[3] or 0
        present = row[4] or 0
        absent = row[5] or 0
        pct = round((present / total) * 100, 2) if total > 0 else 0.0
        results.append({
            "roll_no": row[0], "name": row[1], "branch": row[2],
            "total_days": total, "present_days": present,
            "absent_days": absent, "percentage": pct
        })
    conn.close()
    return results


def get_monthly_report(year, month, subject_id=None):
    """Get monthly report, optionally filtered by subject."""
    conn = get_connection()
    cursor = conn.cursor()
    month_str = f"{year}-{month:02d}%"
    if subject_id:
        cursor.execute("""
            SELECT s.roll_no, s.name, s.branch,
                COUNT(a.id) as total,
                SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present,
                SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) as absent
            FROM students s
            LEFT JOIN attendance a ON s.id = a.student_id AND a.date LIKE ? AND a.subject_id = ?
            GROUP BY s.id ORDER BY s.branch, s.roll_no
        """, (month_str, subject_id))
    else:
        cursor.execute("""
            SELECT s.roll_no, s.name, s.branch,
                COUNT(a.id) as total,
                SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) as present,
                SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) as absent
            FROM students s
            LEFT JOIN attendance a ON s.id = a.student_id AND a.date LIKE ?
            GROUP BY s.id ORDER BY s.branch, s.roll_no
        """, (month_str,))
    results = []
    for row in cursor.fetchall():
        total = row[3] or 0
        present = row[4] or 0
        absent = row[5] or 0
        pct = round((present / total) * 100, 2) if total > 0 else 0.0
        results.append({
            "roll_no": row[0], "name": row[1], "branch": row[2],
            "total_days": total, "present_days": present,
            "absent_days": absent, "percentage": pct
        })
    conn.close()
    return results


def delete_attendance_record(student_id, date, subject_id=None):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        if subject_id:
            cursor.execute(
                "DELETE FROM attendance WHERE student_id=? AND date=? AND subject_id=?",
                (student_id, date, subject_id))
        else:
            cursor.execute(
                "DELETE FROM attendance WHERE student_id=? AND date=?",
                (student_id, date))
        conn.commit()
        return True, "Record deleted!"
    except Exception as e:
        return False, f"Error: {str(e)}"
    finally:
        conn.close()


def get_attendance_dates():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT date FROM attendance ORDER BY date DESC")
    dates = [row[0] for row in cursor.fetchall()]
    conn.close()
    return dates

"""
styles.py — Centralized Styles & Theme Configuration
=====================================================
Premium dark college theme with all colors, fonts, and layout constants.
"""

COLORS = {
    "primary":          "#6C63FF",
    "primary_hover":    "#5A52E0",
    "primary_light":    "#8B83FF",
    "primary_dark":     "#4A42CC",
    "bg_dark":          "#0F0F1A",
    "bg_medium":        "#161625",
    "bg_light":         "#1E1E32",
    "bg_card":          "#24243D",
    "bg_input":         "#2A2A4A",
    "bg_hover":         "#2E2E50",
    "sidebar_bg":       "#0D0D1A",
    "sidebar_active":   "#6C63FF",
    "sidebar_hover":    "#1A1A30",
    "sidebar_border":   "#2A2A45",
    "text_primary":     "#EAEAF0",
    "text_secondary":   "#8888A8",
    "text_muted":       "#5A5A7A",
    "text_on_accent":   "#FFFFFF",
    "success":          "#00D68F",
    "success_hover":    "#00B87A",
    "success_bg":       "#0A2E20",
    "danger":           "#FF4D6A",
    "danger_hover":     "#E03050",
    "danger_bg":        "#2E0A18",
    "warning":          "#FFB74D",
    "warning_bg":       "#2E1F0A",
    "info":             "#40A9FF",
    "info_bg":          "#0A1E2E",
    "border":           "#2A2A45",
    "border_light":     "#35355A",
    "border_focus":     "#6C63FF",
    "table_header":     "#1A1A30",
    "table_row_even":   "#14142A",
    "table_row_odd":    "#1A1A32",
    "table_selected":   "#2E2E5A",
    "gradient_start":   "#6C63FF",
    "gradient_end":     "#B06AFF",
    "gold":             "#FFD700",
    "shadow":           "#000000",
    "login_bg":         "#0A0A15",
    "login_card":       "#151528",
}

FONTS = {
    "heading":          ("Segoe UI Semibold", 22),
    "subheading":       ("Segoe UI Semibold", 15),
    "body":             ("Segoe UI", 12),
    "body_bold":        ("Segoe UI Semibold", 12),
    "small":            ("Segoe UI", 10),
    "small_bold":       ("Segoe UI Semibold", 10),
    "button":           ("Segoe UI Semibold", 12),
    "sidebar":          ("Segoe UI", 13),
    "sidebar_active":   ("Segoe UI Semibold", 13),
    "title":            ("Segoe UI Semibold", 28),
    "input":            ("Segoe UI", 12),
    "table_header":     ("Segoe UI Semibold", 11),
    "table_body":       ("Segoe UI", 11),
    "stats_number":     ("Segoe UI", 32, "bold"),
    "stats_label":      ("Segoe UI", 10),
    "card_value":       ("Segoe UI", 26, "bold"),
    "card_label":       ("Segoe UI", 11),
    "badge":            ("Segoe UI Semibold", 9),
    "login_title":      ("Segoe UI Semibold", 32),
    "login_subtitle":   ("Segoe UI", 13),
}

SIZES = {
    "window_width":     1200,
    "window_height":    750,
    "sidebar_width":    240,
    "card_pad_x":       20,
    "card_pad_y":       18,
    "padding_large":    25,
    "padding_medium":   15,
    "padding_small":    8,
    "input_height":     38,
    "button_height":    40,
    "border_radius":    12,
    "icon_size":        80,
}

TEACHER_MENU_ITEMS = [
    {"label": "  🏠   Dashboard",           "key": "dashboard"},
    {"label": "  ➕   Add Student",          "key": "add_student"},
    {"label": "  📋   Mark Attendance",      "key": "mark_attendance"},
    {"label": "  📊   View Records",         "key": "view_records"},
    {"label": "  🔍   Search Student",       "key": "search_student"},
    {"label": "  📈   Reports",              "key": "reports"},
    {"label": "  🚪   Logout",               "key": "logout"},
]

STUDENT_MENU_ITEMS = [
    {"label": "  🏠   My Dashboard",        "key": "dashboard"},
    {"label": "  📊   My Attendance",        "key": "my_attendance"},
    {"label": "  🚪   Logout",               "key": "logout"},
]

"""
add_student.py — Add Student Frame (Premium UI)
==================================================
GUI frame for registering new students.
"""

import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
from gui.styles import COLORS, FONTS
from database.db_manager import add_student, get_all_students, delete_student
from utils.validators import validate_roll_no, validate_name, validate_branch


class AddStudentFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=COLORS["bg_dark"])
        self._create_widgets()

    def _create_widgets(self):
        canvas = tk.Canvas(self, bg=COLORS["bg_dark"], highlightthickness=0)
        scrollbar = tk.Scrollbar(self, orient="vertical", command=canvas.yview)
        content = tk.Frame(canvas, bg=COLORS["bg_dark"])
        content.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=content, anchor="nw", tags="content")
        canvas.configure(yscrollcommand=scrollbar.set)
        def on_cc(event): canvas.itemconfig("content", width=event.width)
        canvas.bind("<Configure>", on_cc)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        canvas.bind_all("<MouseWheel>",
            lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        # Header
        header = tk.Frame(content, bg=COLORS["bg_medium"])
        header.pack(fill="x", padx=25, pady=(25, 0))
        hi = tk.Frame(header, bg=COLORS["bg_medium"])
        hi.pack(fill="x", padx=25, pady=18)
        tk.Label(hi, text="➕  Add New Student", font=FONTS["heading"],
                 bg=COLORS["bg_medium"], fg=COLORS["text_primary"]).pack(anchor="w")
        tk.Label(hi, text="Register a new student in the attendance system",
                 font=FONTS["body"], bg=COLORS["bg_medium"],
                 fg=COLORS["text_secondary"]).pack(anchor="w", pady=(4, 0))

        # Form Card
        fc = tk.Frame(content, bg=COLORS["bg_light"],
                      highlightbackground=COLORS["border"], highlightthickness=1)
        fc.pack(fill="x", padx=25, pady=(15, 0))
        tk.Frame(fc, bg=COLORS["primary"], height=3).pack(fill="x")
        fi = tk.Frame(fc, bg=COLORS["bg_light"])
        fi.pack(fill="x", padx=25, pady=20)
        tk.Label(fi, text="📝  Student Information", font=FONTS["subheading"],
                 bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(anchor="w", pady=(0, 15))

        ff = tk.Frame(fi, bg=COLORS["bg_light"])
        ff.pack(fill="x")
        self.roll_entry = self._field(ff, "Roll Number", "e.g., BTEH-2026-001")
        self.name_entry = self._field(ff, "Student Name", "e.g., Rahul Sharma")
        self.branch_entry = self._field(ff, "Branch / Class", "e.g., BTEH Sem-2")

        bf = tk.Frame(fi, bg=COLORS["bg_light"])
        bf.pack(anchor="w", pady=(20, 5))
        ctk.CTkButton(bf, text="✅  Add Student", font=("Segoe UI Semibold", 13),
            fg_color=COLORS["success"], hover_color=COLORS["success_hover"],
            corner_radius=8, width=160, height=42,
            command=self._submit).pack(side="left", padx=(0, 10))
        ctk.CTkButton(bf, text="🔄  Clear", font=("Segoe UI Semibold", 13),
            fg_color=COLORS["bg_input"], hover_color=COLORS["bg_hover"],
            text_color=COLORS["text_primary"], corner_radius=8,
            width=120, height=42, command=self._clear).pack(side="left")

        # Table
        ts = tk.Frame(content, bg=COLORS["bg_dark"])
        ts.pack(fill="both", expand=True, padx=25, pady=(15, 25))

        top_row = tk.Frame(ts, bg=COLORS["bg_dark"])
        top_row.pack(fill="x", pady=(0, 10))
        tk.Label(top_row, text="📋  All Students", font=FONTS["subheading"],
                 bg=COLORS["bg_dark"], fg=COLORS["text_primary"]).pack(side="left")
        ctk.CTkButton(top_row, text="🗑  Delete Selected", font=("Segoe UI Semibold", 11),
            fg_color=COLORS["danger"], hover_color=COLORS["danger_hover"],
            corner_radius=6, width=150, height=32,
            command=self._delete_selected).pack(side="right")

        tc = tk.Frame(ts, bg=COLORS["bg_light"],
                      highlightbackground=COLORS["border"], highlightthickness=1)
        tc.pack(fill="both", expand=True)

        hr = tk.Frame(tc, bg=COLORS["table_header"])
        hr.pack(fill="x")
        for t, w in [("  #", 4), ("Roll No.", 14), ("Name", 22), ("Branch", 18), ("Added On", 16)]:
            tk.Label(hr, text=t, font=FONTS["table_header"],
                     bg=COLORS["table_header"], fg=COLORS["primary_light"],
                     width=w, anchor="w", padx=8, pady=10).pack(side="left")

        lc = tk.Frame(tc, bg=COLORS["bg_dark"])
        lc.pack(fill="both", expand=True)
        sb = tk.Scrollbar(lc)
        sb.pack(side="right", fill="y")
        self.student_list = tk.Listbox(lc, font=FONTS["table_body"],
            bg=COLORS["bg_dark"], fg=COLORS["text_primary"],
            selectbackground=COLORS["table_selected"], selectforeground="white",
            relief="flat", highlightthickness=0, yscrollcommand=sb.set, activestyle="none")
        self.student_list.pack(fill="both", expand=True)
        sb.config(command=self.student_list.yview)
        self._students_data = []
        self._refresh()

    def _field(self, parent, label, placeholder):
        f = tk.Frame(parent, bg=COLORS["bg_light"])
        f.pack(fill="x", pady=(0, 12))
        tk.Label(f, text=label, font=FONTS["body_bold"],
                 bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(anchor="w", pady=(0, 4))
        entry = ctk.CTkEntry(f, font=("Segoe UI", 12), fg_color=COLORS["bg_input"],
            border_color=COLORS["border"], text_color=COLORS["text_primary"],
            placeholder_text=placeholder, placeholder_text_color=COLORS["text_muted"],
            corner_radius=6, height=38, width=400, border_width=1)
        entry.pack(anchor="w")
        return entry

    def _submit(self):
        r, n, b = self.roll_entry.get().strip(), self.name_entry.get().strip(), self.branch_entry.get().strip()
        for val, v in [(validate_roll_no, r), (validate_name, n), (validate_branch, b)]:
            ok, err = val(v)
            if not ok:
                messagebox.showwarning("Validation Error", err)
                return
        ok, msg = add_student(r, n, b)
        if ok:
            messagebox.showinfo("Success", msg)
            self._clear()
            self._refresh()
        else:
            messagebox.showerror("Error", msg)

    def _clear(self):
        for e in [self.roll_entry, self.name_entry, self.branch_entry]:
            e.delete(0, "end")

    def _delete_selected(self):
        sel = self.student_list.curselection()
        if not sel:
            messagebox.showwarning("No Selection", "Select a student to delete!")
            return
        idx = sel[0]
        if idx < len(self._students_data):
            s = self._students_data[idx]
            if messagebox.askyesno("Confirm Delete",
                    f"Delete student '{s[2]}' ({s[1]})?\nAll attendance records will also be deleted!"):
                ok, msg = delete_student(s[0])
                if ok:
                    messagebox.showinfo("Deleted", msg)
                    self._refresh()
                else:
                    messagebox.showerror("Error", msg)

    def _refresh(self):
        self.student_list.delete(0, "end")
        self._students_data = get_all_students()
        if not self._students_data:
            self.student_list.insert("end", "    No students registered yet.")
            return
        for i, s in enumerate(self._students_data):
            _id, roll, name, branch, created = s
            d = created.split(" ")[0] if created else "N/A"
            line = f"  {i+1:<5}{roll:<16}{name:<24}{branch:<20}{d}"
            self.student_list.insert("end", line)
            bg = COLORS["table_row_even"] if i % 2 == 0 else COLORS["table_row_odd"]
            self.student_list.itemconfig(i, bg=bg)

"""
view_records.py — View All Attendance Records (Premium UI)
Subject-scoped: Teacher sees only records for their assigned subject.
"""

import tkinter as tk
import customtkinter as ctk
from gui.styles import COLORS, FONTS
from database.db_manager import get_all_attendance_records


class ViewRecordsFrame(tk.Frame):
    def __init__(self, parent, subject_id=None):
        super().__init__(parent, bg=COLORS["bg_dark"])
        self.subject_id = subject_id
        self._create_widgets()

    def _create_widgets(self):
        header = tk.Frame(self, bg=COLORS["bg_medium"])
        header.pack(fill="x", padx=25, pady=(25, 0))
        hi = tk.Frame(header, bg=COLORS["bg_medium"])
        hi.pack(fill="x", padx=25, pady=18)
        tk.Label(hi, text="📊  All Attendance Records", font=FONTS["heading"],
                 bg=COLORS["bg_medium"], fg=COLORS["text_primary"]).pack(anchor="w")
        tk.Label(hi, text="Complete attendance history for all students",
                 font=FONTS["body"], bg=COLORS["bg_medium"],
                 fg=COLORS["text_secondary"]).pack(anchor="w", pady=(4, 0))

        controls = tk.Frame(self, bg=COLORS["bg_dark"])
        controls.pack(fill="x", padx=25, pady=(15, 10))
        ctk.CTkButton(controls, text="🔄  Refresh", font=("Segoe UI Semibold", 12),
            fg_color=COLORS["primary"], hover_color=COLORS["primary_hover"],
            corner_radius=8, width=140, height=38,
            command=self._load).pack(side="left")
        self.count_label = tk.Label(controls, text="", font=FONTS["body_bold"],
            bg=COLORS["bg_dark"], fg=COLORS["text_secondary"])
        self.count_label.pack(side="right")

        tc = tk.Frame(self, bg=COLORS["bg_light"],
                      highlightbackground=COLORS["border"], highlightthickness=1)
        tc.pack(fill="both", expand=True, padx=25, pady=(0, 25))

        hr = tk.Frame(tc, bg=COLORS["table_header"])
        hr.pack(fill="x")
        for t, w in [("  Roll No.", 13), ("Name", 18), ("Branch", 14),
                      ("Date", 12), ("Subject", 14), ("Status", 10)]:
            tk.Label(hr, text=t, font=FONTS["table_header"],
                     bg=COLORS["table_header"], fg=COLORS["primary_light"],
                     width=w, anchor="w", padx=8, pady=10).pack(side="left")

        lc = tk.Frame(tc, bg=COLORS["bg_dark"])
        lc.pack(fill="both", expand=True)
        sb = tk.Scrollbar(lc)
        sb.pack(side="right", fill="y")
        self.record_list = tk.Listbox(lc, font=FONTS["table_body"],
            bg=COLORS["bg_dark"], fg=COLORS["text_primary"],
            selectbackground=COLORS["table_selected"], selectforeground="white",
            relief="flat", highlightthickness=0, yscrollcommand=sb.set, activestyle="none")
        self.record_list.pack(fill="both", expand=True)
        sb.config(command=self.record_list.yview)
        self._load()

    def _load(self):
        self.record_list.delete(0, "end")
        records = get_all_attendance_records(subject_id=self.subject_id)
        self.count_label.config(text=f"📋  Total: {len(records)}")
        if not records:
            self.record_list.insert("end", "    No records found.")
            return
        for i, (roll, name, branch, date, status, subject) in enumerate(records):
            icon = "✅" if status == "Present" else "❌"
            line = f"  {roll:<15}{name:<20}{branch:<16}{date:<14}{subject:<16}{icon} {status}"
            self.record_list.insert("end", line)
            bg = COLORS["table_row_even"] if i % 2 == 0 else COLORS["table_row_odd"]
            self.record_list.itemconfig(i, bg=bg)
            if status == "Absent":
                self.record_list.itemconfig(i, fg=COLORS["danger"])

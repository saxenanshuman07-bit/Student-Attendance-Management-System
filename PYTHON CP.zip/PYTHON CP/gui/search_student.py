"""
search_student.py — Search Student Attendance (Premium UI)
"""

import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
from gui.styles import COLORS, FONTS
from database.db_manager import (
    get_student_by_roll_no, get_attendance_by_roll_no,
    get_attendance_percentage, get_subject_wise_attendance, search_students
)
from utils.validators import validate_roll_no


class SearchStudentFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=COLORS["bg_dark"])
        self._create_widgets()

    def _create_widgets(self):
        header = tk.Frame(self, bg=COLORS["bg_medium"])
        header.pack(fill="x", padx=25, pady=(25, 0))
        hi = tk.Frame(header, bg=COLORS["bg_medium"])
        hi.pack(fill="x", padx=25, pady=18)
        tk.Label(hi, text="🔍  Search Student", font=FONTS["heading"],
                 bg=COLORS["bg_medium"], fg=COLORS["text_primary"]).pack(anchor="w")
        tk.Label(hi, text="Search by roll number, name, or branch",
                 font=FONTS["body"], bg=COLORS["bg_medium"],
                 fg=COLORS["text_secondary"]).pack(anchor="w", pady=(4, 0))

        # Search bar
        sc = tk.Frame(self, bg=COLORS["bg_light"],
                      highlightbackground=COLORS["border"], highlightthickness=1)
        sc.pack(fill="x", padx=25, pady=(15, 0))
        tk.Frame(sc, bg=COLORS["warning"], height=3).pack(fill="x")
        si = tk.Frame(sc, bg=COLORS["bg_light"])
        si.pack(fill="x", padx=20, pady=15)

        tk.Label(si, text="🎓 Search:", font=FONTS["body_bold"],
                 bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(side="left", padx=(0, 8))
        self.search_entry = ctk.CTkEntry(si, font=("Segoe UI", 12),
            fg_color=COLORS["bg_input"], border_color=COLORS["border"],
            text_color=COLORS["text_primary"],
            placeholder_text="Roll number, name, or branch...",
            placeholder_text_color=COLORS["text_muted"],
            corner_radius=6, height=38, width=280, border_width=1)
        self.search_entry.pack(side="left", padx=(0, 10))
        self.search_entry.bind("<Return>", lambda e: self._search())

        ctk.CTkButton(si, text="🔍 Search", font=("Segoe UI Semibold", 12),
            fg_color=COLORS["primary"], hover_color=COLORS["primary_hover"],
            corner_radius=6, width=120, height=38,
            command=self._search).pack(side="left", padx=(0, 8))
        ctk.CTkButton(si, text="📋 Show All", font=("Segoe UI Semibold", 12),
            fg_color=COLORS["bg_input"], hover_color=COLORS["bg_hover"],
            text_color=COLORS["text_primary"],
            corner_radius=6, width=120, height=38,
            command=self._show_all).pack(side="left")

        self.info_frame = tk.Frame(self, bg=COLORS["bg_dark"])
        self.info_frame.pack(fill="x", padx=25, pady=(15, 0))
        self.records_frame = tk.Frame(self, bg=COLORS["bg_dark"])
        self.records_frame.pack(fill="both", expand=True, padx=25, pady=(0, 25))

    def _search(self):
        query = self.search_entry.get().strip()
        if not query:
            messagebox.showwarning("Empty", "Enter a search term!"); return

        for w in self.info_frame.winfo_children(): w.destroy()
        for w in self.records_frame.winfo_children(): w.destroy()

        # Try exact roll number match first
        student = get_student_by_roll_no(query)
        if student:
            self._show_student_detail(student)
            return

        # Otherwise search broadly
        results = search_students(query)
        if not results:
            tk.Label(self.info_frame, text=f"No results for '{query}'",
                     font=FONTS["body"], bg=COLORS["bg_dark"],
                     fg=COLORS["text_secondary"]).pack(pady=20)
            return

        self._show_results_list(results)

    def _show_all(self):
        from database.db_manager import get_all_students
        for w in self.info_frame.winfo_children(): w.destroy()
        for w in self.records_frame.winfo_children(): w.destroy()
        self._show_results_list(get_all_students())

    def _show_results_list(self, results):
        tk.Label(self.info_frame, text=f"📋 Found {len(results)} student(s)",
                 font=FONTS["subheading"], bg=COLORS["bg_dark"],
                 fg=COLORS["text_primary"]).pack(anchor="w", pady=(0, 8))

        tc = tk.Frame(self.records_frame, bg=COLORS["bg_light"],
                      highlightbackground=COLORS["border"], highlightthickness=1)
        tc.pack(fill="both", expand=True)
        hr = tk.Frame(tc, bg=COLORS["table_header"])
        hr.pack(fill="x")
        for t, w in [("  Roll No.", 14), ("Name", 22), ("Branch", 18), ("Action", 12)]:
            tk.Label(hr, text=t, font=FONTS["table_header"],
                     bg=COLORS["table_header"], fg=COLORS["primary_light"],
                     width=w, anchor="w", padx=8, pady=10).pack(side="left")

        canvas = tk.Canvas(tc, bg=COLORS["bg_dark"], highlightthickness=0)
        sb = tk.Scrollbar(tc, orient="vertical", command=canvas.yview)
        sf = tk.Frame(canvas, bg=COLORS["bg_dark"])
        sf.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=sf, anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        for i, s in enumerate(results):
            rbg = COLORS["table_row_even"] if i % 2 == 0 else COLORS["table_row_odd"]
            row = tk.Frame(sf, bg=rbg)
            row.pack(fill="x")
            tk.Label(row, text=f"  {s[1]}", font=FONTS["table_body"], bg=rbg,
                     fg=COLORS["text_primary"], width=14, anchor="w", padx=8, pady=8).pack(side="left")
            tk.Label(row, text=s[2], font=FONTS["table_body"], bg=rbg,
                     fg=COLORS["text_primary"], width=22, anchor="w", padx=8).pack(side="left")
            tk.Label(row, text=s[3], font=FONTS["table_body"], bg=rbg,
                     fg=COLORS["text_secondary"], width=18, anchor="w", padx=8).pack(side="left")
            view_btn = tk.Label(row, text="  View  ", font=FONTS["badge"],
                bg=COLORS["primary"], fg="white", padx=8, pady=3, cursor="hand2")
            view_btn.pack(side="left", padx=8)
            view_btn.bind("<Button-1>", lambda e, st=s: self._view_student(st))

    def _view_student(self, student_tuple):
        for w in self.info_frame.winfo_children(): w.destroy()
        for w in self.records_frame.winfo_children(): w.destroy()
        self._show_student_detail(student_tuple)

    def _show_student_detail(self, student):
        sid, s_roll, s_name, s_branch = student[0], student[1], student[2], student[3]
        stats = get_attendance_percentage(s_roll)
        subj_stats = get_subject_wise_attendance(s_roll)

        # Student Info Card
        card = tk.Frame(self.info_frame, bg=COLORS["bg_light"],
                        highlightbackground=COLORS["border"], highlightthickness=1)
        card.pack(fill="x")
        tk.Frame(card, bg=COLORS["primary"], height=3).pack(fill="x")
        ci = tk.Frame(card, bg=COLORS["bg_light"])
        ci.pack(fill="x", padx=22, pady=18)

        il = tk.Frame(ci, bg=COLORS["bg_light"])
        il.pack(side="left", fill="x", expand=True)
        tk.Label(il, text=f"👤  {s_name}", font=FONTS["subheading"],
                 bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(anchor="w")
        dr = tk.Frame(il, bg=COLORS["bg_light"])
        dr.pack(anchor="w", pady=(6, 0))
        tk.Label(dr, text=f"  {s_roll}  ", font=FONTS["badge"],
                 bg=COLORS["primary"], fg="white", padx=6, pady=2).pack(side="left", padx=(0, 8))
        tk.Label(dr, text=f"  {s_branch}  ", font=FONTS["badge"],
                 bg=COLORS["bg_input"], fg=COLORS["text_secondary"], padx=6, pady=2).pack(side="left")

        if stats:
            pct = stats["percentage"]
            pc = COLORS["success"] if pct >= 75 else (COLORS["warning"] if pct >= 50 else COLORS["danger"])
            sr = tk.Frame(ci, bg=COLORS["bg_light"])
            sr.pack(side="right")
            ms = tk.Frame(sr, bg=COLORS["bg_light"])
            ms.pack(side="left", padx=(0, 20))
            for lb, vl, cl in [("Present", stats["present_days"], COLORS["success"]),
                                ("Absent", stats["absent_days"], COLORS["danger"]),
                                ("Total", stats["total_days"], COLORS["info"])]:
                sf = tk.Frame(ms, bg=COLORS["bg_light"])
                sf.pack(side="left", padx=10)
                tk.Label(sf, text=str(vl), font=("Segoe UI", 20, "bold"),
                         bg=COLORS["bg_light"], fg=cl).pack()
                tk.Label(sf, text=lb, font=FONTS["small"],
                         bg=COLORS["bg_light"], fg=COLORS["text_muted"]).pack()
            pf = tk.Frame(sr, bg=COLORS["bg_light"])
            pf.pack(side="left")
            tk.Label(pf, text=f"{pct}%", font=("Segoe UI", 28, "bold"),
                     bg=COLORS["bg_light"], fg=pc).pack()
            tk.Label(pf, text="Attendance", font=FONTS["small_bold"],
                     bg=COLORS["bg_light"], fg=COLORS["text_muted"]).pack()

        # Subject-wise attendance
        if subj_stats:
            tk.Label(self.records_frame, text="📚  Subject-wise Attendance",
                     font=FONTS["subheading"], bg=COLORS["bg_dark"],
                     fg=COLORS["text_primary"]).pack(anchor="w", pady=(10, 8))
            sfc = tk.Frame(self.records_frame, bg=COLORS["bg_dark"])
            sfc.pack(fill="x", pady=(0, 10))
            for i in range(min(len(subj_stats), 5)):
                sfc.grid_columnconfigure(i, weight=1, uniform="subj")
            for i, ss in enumerate(subj_stats[:5]):
                sc = tk.Frame(sfc, bg=COLORS["bg_light"],
                              highlightbackground=COLORS["border"], highlightthickness=1)
                sc.grid(row=0, column=i, padx=(0, 8) if i < len(subj_stats)-1 else 0, sticky="nsew")
                spc = COLORS["success"] if ss["percentage"] >= 75 else (
                    COLORS["warning"] if ss["percentage"] >= 50 else COLORS["danger"])
                tk.Frame(sc, bg=spc, height=3).pack(fill="x")
                sci = tk.Frame(sc, bg=COLORS["bg_light"])
                sci.pack(padx=12, pady=10)
                tk.Label(sci, text=ss["subject"], font=FONTS["small_bold"],
                         bg=COLORS["bg_light"], fg=COLORS["text_secondary"]).pack()
                tk.Label(sci, text=f"{ss['percentage']}%", font=("Segoe UI", 18, "bold"),
                         bg=COLORS["bg_light"], fg=spc).pack()
                tk.Label(sci, text=f"{ss['present']}/{ss['total']}",
                         font=FONTS["small"], bg=COLORS["bg_light"],
                         fg=COLORS["text_muted"]).pack()

        # History table
        tk.Label(self.records_frame, text="📋  Attendance History",
                 font=FONTS["subheading"], bg=COLORS["bg_dark"],
                 fg=COLORS["text_primary"]).pack(anchor="w", pady=(5, 8))
        records = get_attendance_by_roll_no(s_roll)
        if not records:
            tk.Label(self.records_frame, text="No attendance records.",
                     font=FONTS["body"], bg=COLORS["bg_dark"],
                     fg=COLORS["text_secondary"]).pack(anchor="w")
            return

        tc = tk.Frame(self.records_frame, bg=COLORS["bg_light"],
                      highlightbackground=COLORS["border"], highlightthickness=1)
        tc.pack(fill="both", expand=True)
        hr = tk.Frame(tc, bg=COLORS["table_header"])
        hr.pack(fill="x")
        for t, w in [("  Date", 20), ("Subject", 20), ("Status", 15)]:
            tk.Label(hr, text=t, font=FONTS["table_header"],
                     bg=COLORS["table_header"], fg=COLORS["primary_light"],
                     width=w, anchor="w", padx=10, pady=10).pack(side="left")
        lc = tk.Frame(tc, bg=COLORS["bg_dark"])
        lc.pack(fill="both", expand=True)
        sb = tk.Scrollbar(lc)
        sb.pack(side="right", fill="y")
        lb = tk.Listbox(lc, font=FONTS["table_body"], bg=COLORS["bg_dark"],
            fg=COLORS["text_primary"], selectbackground=COLORS["table_selected"],
            relief="flat", highlightthickness=0, yscrollcommand=sb.set, activestyle="none")
        lb.pack(fill="both", expand=True)
        sb.config(command=lb.yview)
        for i, (date, status, subject) in enumerate(records):
            icon = "✅" if status == "Present" else "❌"
            lb.insert("end", f"    {date:<22}{subject:<22}{icon}  {status}")
            bg = COLORS["table_row_even"] if i % 2 == 0 else COLORS["table_row_odd"]
            lb.itemconfig(i, bg=bg)
            if status == "Absent": lb.itemconfig(i, fg=COLORS["danger"])

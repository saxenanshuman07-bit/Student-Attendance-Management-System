"""
mark_attendance.py — Mark Attendance Frame (Premium UI)
=========================================================
Mark daily attendance with Present/Absent toggles.
Subject is locked to the teacher's assigned subject.
"""

import tkinter as tk
from tkinter import messagebox
from datetime import datetime
import customtkinter as ctk
from gui.styles import COLORS, FONTS
from database.db_manager import (
    get_all_branches, get_students_by_branch,
    mark_bulk_attendance, get_all_students
)
from utils.validators import validate_date


class MarkAttendanceFrame(tk.Frame):
    def __init__(self, parent, subject_id=None, subject_name="General"):
        super().__init__(parent, bg=COLORS["bg_dark"])
        self.subject_id = subject_id
        self.subject_name = subject_name or "General"
        self.attendance_vars = {}
        self._create_widgets()

    def _create_widgets(self):
        # Header
        header = tk.Frame(self, bg=COLORS["bg_medium"])
        header.pack(fill="x", padx=25, pady=(25, 0))
        hi = tk.Frame(header, bg=COLORS["bg_medium"])
        hi.pack(fill="x", padx=25, pady=18)
        tk.Label(hi, text=f"📋  Mark Attendance — {self.subject_name}", font=FONTS["heading"],
                 bg=COLORS["bg_medium"], fg=COLORS["text_primary"]).pack(anchor="w")
        tk.Label(hi, text=f"Marking attendance for: {self.subject_name}  •  Select date and branch, then mark Present/Absent",
                 font=FONTS["body"], bg=COLORS["bg_medium"],
                 fg=COLORS["text_secondary"]).pack(anchor="w", pady=(4, 0))

        # Controls
        cc = tk.Frame(self, bg=COLORS["bg_light"],
                      highlightbackground=COLORS["border"], highlightthickness=1)
        cc.pack(fill="x", padx=25, pady=(15, 0))
        tk.Frame(cc, bg=COLORS["info"], height=3).pack(fill="x")
        ci = tk.Frame(cc, bg=COLORS["bg_light"])
        ci.pack(fill="x", padx=20, pady=15)

        tk.Label(ci, text="📅 Date:", font=FONTS["body_bold"],
                 bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(side="left", padx=(0, 5))
        self.date_entry = ctk.CTkEntry(ci, font=("Segoe UI", 12),
            fg_color=COLORS["bg_input"], border_color=COLORS["border"],
            text_color=COLORS["text_primary"], corner_radius=6,
            height=36, width=130, border_width=1)
        self.date_entry.pack(side="left", padx=(0, 12))
        self.date_entry.insert(0, datetime.now().strftime("%Y-%m-%d"))

        # Subject (locked — shown as a label badge)
        tk.Label(ci, text="📚 Subject:", font=FONTS["body_bold"],
                 bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(side="left", padx=(0, 5))
        subj_badge = tk.Label(ci, text=f"  {self.subject_name}  ",
                              font=FONTS["body_bold"],
                              bg=COLORS["warning"], fg="#1A1A30",
                              padx=8, pady=4)
        subj_badge.pack(side="left", padx=(0, 12))

        # Branch
        tk.Label(ci, text="🏫 Branch:", font=FONTS["body_bold"],
                 bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(side="left", padx=(0, 5))
        branches = ["All"] + get_all_branches()
        self.branch_var = tk.StringVar(value="All")
        ctk.CTkOptionMenu(ci, values=branches, variable=self.branch_var,
            font=("Segoe UI", 11), fg_color=COLORS["bg_input"],
            button_color=COLORS["primary"], button_hover_color=COLORS["primary_hover"],
            dropdown_fg_color=COLORS["bg_light"], dropdown_hover_color=COLORS["bg_hover"],
            text_color=COLORS["text_primary"], corner_radius=6,
            width=140, height=36).pack(side="left", padx=(0, 10))

        ctk.CTkButton(ci, text="📥 Load", font=("Segoe UI Semibold", 11),
            fg_color=COLORS["primary"], hover_color=COLORS["primary_hover"],
            corner_radius=6, width=100, height=36,
            command=self._load_students).pack(side="left")

        self.count_label = tk.Label(ci, text="", font=FONTS["small_bold"],
                                     bg=COLORS["bg_light"], fg=COLORS["text_muted"])
        self.count_label.pack(side="right")

        # Table
        tf = tk.Frame(self, bg=COLORS["bg_dark"])
        tf.pack(fill="both", expand=True, padx=25, pady=(10, 0))
        th = tk.Frame(tf, bg=COLORS["table_header"])
        th.pack(fill="x")
        for t, w in [("  Roll No.", 14), ("Name", 22), ("Branch", 15), ("Status", 25)]:
            tk.Label(th, text=t, font=FONTS["table_header"],
                     bg=COLORS["table_header"], fg=COLORS["primary_light"],
                     width=w, anchor="w", padx=8, pady=10).pack(side="left")

        cf = tk.Frame(tf, bg=COLORS["bg_dark"])
        cf.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(cf, bg=COLORS["bg_dark"], highlightthickness=0)
        sb = tk.Scrollbar(cf, orient="vertical", command=self.canvas.yview)
        self.scroll_frame = tk.Frame(self.canvas, bg=COLORS["bg_dark"])
        self.scroll_frame.bind("<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=sb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.canvas.bind_all("<MouseWheel>",
            lambda e: self.canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        # Bottom buttons
        bottom = tk.Frame(self, bg=COLORS["bg_dark"])
        bottom.pack(fill="x", padx=25, pady=(10, 20))
        lb = tk.Frame(bottom, bg=COLORS["bg_dark"])
        lb.pack(side="left")
        ctk.CTkButton(lb, text="✅ All Present", font=("Segoe UI Semibold", 12),
            fg_color=COLORS["success"], hover_color=COLORS["success_hover"],
            corner_radius=8, width=140, height=40,
            command=lambda: self._mark_all("Present")).pack(side="left", padx=(0, 10))
        ctk.CTkButton(lb, text="❌ All Absent", font=("Segoe UI Semibold", 12),
            fg_color=COLORS["danger"], hover_color=COLORS["danger_hover"],
            corner_radius=8, width=140, height=40,
            command=lambda: self._mark_all("Absent")).pack(side="left")
        ctk.CTkButton(bottom, text=f"💾  Submit {self.subject_name} Attendance",
            font=("Segoe UI Semibold", 13),
            fg_color=COLORS["primary"], hover_color=COLORS["primary_hover"],
            corner_radius=8, width=260, height=42,
            command=self._submit).pack(side="right")

        self._load_students()

    def _load_students(self):
        for w in self.scroll_frame.winfo_children(): w.destroy()
        self.attendance_vars.clear()
        branch = self.branch_var.get()
        if branch == "All":
            students = [(s[0], s[1], s[2], s[3]) for s in get_all_students()]
        else:
            students = get_students_by_branch(branch)
        self.count_label.config(text=f"📊 {len(students)} students")
        if not students:
            tk.Label(self.scroll_frame, text="No students found.",
                     font=FONTS["body"], bg=COLORS["bg_dark"],
                     fg=COLORS["text_secondary"]).pack(pady=30)
            return
        for i, (sid, roll, name, br) in enumerate(students):
            rbg = COLORS["table_row_even"] if i % 2 == 0 else COLORS["table_row_odd"]
            row = tk.Frame(self.scroll_frame, bg=rbg)
            row.pack(fill="x")
            tk.Label(row, text=f"  {roll}", font=FONTS["table_body"], bg=rbg,
                     fg=COLORS["text_primary"], width=14, anchor="w", padx=8, pady=10).pack(side="left")
            tk.Label(row, text=name, font=FONTS["table_body"], bg=rbg,
                     fg=COLORS["text_primary"], width=22, anchor="w", padx=8).pack(side="left")
            tk.Label(row, text=br, font=FONTS["table_body"], bg=rbg,
                     fg=COLORS["text_secondary"], width=15, anchor="w", padx=8).pack(side="left")
            var = tk.StringVar(value="Present")
            self.attendance_vars[sid] = var
            sf = tk.Frame(row, bg=rbg)
            sf.pack(side="left", padx=10)
            tk.Radiobutton(sf, text=" Present", variable=var, value="Present",
                font=FONTS["small_bold"], bg=rbg, fg=COLORS["success"],
                selectcolor=COLORS["bg_input"], activebackground=rbg,
                activeforeground=COLORS["success"]).pack(side="left", padx=(0, 12))
            tk.Radiobutton(sf, text=" Absent", variable=var, value="Absent",
                font=FONTS["small_bold"], bg=rbg, fg=COLORS["danger"],
                selectcolor=COLORS["bg_input"], activebackground=rbg,
                activeforeground=COLORS["danger"]).pack(side="left")

    def _mark_all(self, status):
        for v in self.attendance_vars.values(): v.set(status)

    def _submit(self):
        ok, err = validate_date(self.date_entry.get().strip())
        if not ok:
            messagebox.showwarning("Validation Error", err); return
        if not self.attendance_vars:
            messagebox.showwarning("No Students", "Load students first!"); return
        date_str = self.date_entry.get().strip()
        total = len(self.attendance_vars)
        present = sum(1 for v in self.attendance_vars.values() if v.get() == "Present")
        if not messagebox.askyesno("Confirm",
                f"📅 Date: {date_str}\n📚 Subject: {self.subject_name}\n✅ Present: {present}/{total}\n❌ Absent: {total-present}/{total}\n\nSubmit?"):
            return
        records = [(sid, date_str, v.get(), self.subject_id) for sid, v in self.attendance_vars.items()]
        ok, msg = mark_bulk_attendance(records)
        if ok: messagebox.showinfo("Success", msg)
        else: messagebox.showerror("Error", msg)

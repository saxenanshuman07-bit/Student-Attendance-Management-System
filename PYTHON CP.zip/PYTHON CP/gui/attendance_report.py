"""
attendance_report.py — Reports & Statistics (Premium UI)
Subject-scoped: Reports are filtered by the teacher's assigned subject.
"""

import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
import csv
import os
from datetime import datetime
from gui.styles import COLORS, FONTS
from database.db_manager import get_monthly_report, get_all_students_percentage

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPORTS_DIR = os.path.join(BASE_DIR, "reports")


class AttendanceReportFrame(tk.Frame):
    def __init__(self, parent, subject_id=None, subject_name="General"):
        super().__init__(parent, bg=COLORS["bg_dark"])
        self.subject_id = subject_id
        self.subject_name = subject_name or "General"
        self.current_report = []
        self.report_title = ""
        self._create_widgets()

    def _create_widgets(self):
        header = tk.Frame(self, bg=COLORS["bg_medium"])
        header.pack(fill="x", padx=25, pady=(25, 0))
        hi = tk.Frame(header, bg=COLORS["bg_medium"])
        hi.pack(fill="x", padx=25, pady=18)
        tk.Label(hi, text=f"📈  Attendance Reports — {self.subject_name}", font=FONTS["heading"],
                 bg=COLORS["bg_medium"], fg=COLORS["text_primary"]).pack(anchor="w")
        tk.Label(hi, text=f"Generate monthly reports for {self.subject_name} and export to CSV",
                 font=FONTS["body"], bg=COLORS["bg_medium"],
                 fg=COLORS["text_secondary"]).pack(anchor="w", pady=(4, 0))

        cc = tk.Frame(self, bg=COLORS["bg_light"],
                      highlightbackground=COLORS["border"], highlightthickness=1)
        cc.pack(fill="x", padx=25, pady=(15, 0))
        tk.Frame(cc, bg=COLORS["primary"], height=3).pack(fill="x")
        ci = tk.Frame(cc, bg=COLORS["bg_light"])
        ci.pack(fill="x", padx=20, pady=15)

        tk.Label(ci, text="📅 Month:", font=FONTS["body_bold"],
                 bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(side="left", padx=(0, 5))
        months = [str(i) for i in range(1, 13)]
        self.month_var = tk.StringVar(value=str(datetime.now().month))
        ctk.CTkOptionMenu(ci, values=months, variable=self.month_var,
            font=("Segoe UI", 12), fg_color=COLORS["bg_input"],
            button_color=COLORS["primary"], button_hover_color=COLORS["primary_hover"],
            dropdown_fg_color=COLORS["bg_light"], dropdown_hover_color=COLORS["bg_hover"],
            text_color=COLORS["text_primary"], corner_radius=6,
            width=80, height=36).pack(side="left", padx=(0, 12))

        tk.Label(ci, text="📆 Year:", font=FONTS["body_bold"],
                 bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(side="left", padx=(0, 5))
        years = [str(y) for y in range(2024, 2031)]
        self.year_var = tk.StringVar(value=str(datetime.now().year))
        ctk.CTkOptionMenu(ci, values=years, variable=self.year_var,
            font=("Segoe UI", 12), fg_color=COLORS["bg_input"],
            button_color=COLORS["primary"], button_hover_color=COLORS["primary_hover"],
            dropdown_fg_color=COLORS["bg_light"], dropdown_hover_color=COLORS["bg_hover"],
            text_color=COLORS["text_primary"], corner_radius=6,
            width=100, height=36).pack(side="left", padx=(0, 12))

        ctk.CTkButton(ci, text="📊 Generate", font=("Segoe UI Semibold", 12),
            fg_color=COLORS["primary"], hover_color=COLORS["primary_hover"],
            corner_radius=6, width=120, height=36,
            command=self._gen).pack(side="left", padx=(0, 8))
        ctk.CTkButton(ci, text="💾 Export CSV", font=("Segoe UI Semibold", 12),
            fg_color=COLORS["success"], hover_color=COLORS["success_hover"],
            corner_radius=6, width=120, height=36,
            command=self._export).pack(side="left", padx=(0, 8))
        ctk.CTkButton(ci, text="📋 Overall", font=("Segoe UI Semibold", 12),
            fg_color=COLORS["warning"], hover_color="#E6A030",
            text_color="#1A1A30", corner_radius=6, width=110, height=36,
            command=self._overall).pack(side="left")

        self.stats_frame = tk.Frame(self, bg=COLORS["bg_dark"])
        self.stats_frame.pack(fill="x", padx=25, pady=(12, 0))
        self.table_frame = tk.Frame(self, bg=COLORS["bg_dark"])
        self.table_frame.pack(fill="both", expand=True, padx=25, pady=(0, 25))

    def _gen(self):
        month = int(self.month_var.get())
        year = int(self.year_var.get())
        mn = ["", "January", "February", "March", "April", "May", "June",
              "July", "August", "September", "October", "November", "December"]
        self.report_title = f"{mn[month]} {year} — {self.subject_name}"
        self.current_report = get_monthly_report(year, month, subject_id=self.subject_id)
        self._display(self.current_report, f"📅  Monthly Report — {self.report_title}")

    def _overall(self):
        self.current_report = get_all_students_percentage(subject_id=self.subject_id)
        self.report_title = f"Overall — {self.subject_name}"
        self._display(self.current_report, f"📋  Overall {self.subject_name} Attendance Statistics")

    def _display(self, report, title):
        for w in self.stats_frame.winfo_children(): w.destroy()
        for w in self.table_frame.winfo_children(): w.destroy()
        if not report:
            tk.Label(self.table_frame, text="📭  No data found.",
                     font=FONTS["body"], bg=COLORS["bg_dark"],
                     fg=COLORS["text_secondary"]).pack(pady=30)
            return

        ts = len(report)
        swd = [r for r in report if r["total_days"] > 0]
        avg = (sum(r["percentage"] for r in swd) / len(swd)) if swd else 0
        low = sum(1 for r in swd if r["percentage"] < 75)

        for i in range(3):
            self.stats_frame.grid_columnconfigure(i, weight=1, uniform="sc")
        for i, (lb, vl, ic, cl) in enumerate([
            ("Total Students", str(ts), "👨‍🎓", COLORS["primary"]),
            ("Avg Attendance", f"{avg:.1f}%", "📊", COLORS["success"]),
            ("Below 75%", str(low), "⚠️", COLORS["danger"])]):
            cd = tk.Frame(self.stats_frame, bg=COLORS["bg_light"],
                          highlightbackground=COLORS["border"], highlightthickness=1)
            cd.grid(row=0, column=i, padx=(0, 12) if i < 2 else 0, sticky="nsew")
            tk.Frame(cd, bg=cl, height=3).pack(fill="x")
            cdi = tk.Frame(cd, bg=COLORS["bg_light"])
            cdi.pack(padx=18, pady=14)
            tk.Label(cdi, text=f"{ic}  {lb}", font=FONTS["small_bold"],
                     bg=COLORS["bg_light"], fg=COLORS["text_muted"]).pack(anchor="w")
            tk.Label(cdi, text=vl, font=FONTS["card_value"],
                     bg=COLORS["bg_light"], fg=cl).pack(anchor="w", pady=(4, 0))

        tk.Label(self.table_frame, text=title, font=FONTS["subheading"],
                 bg=COLORS["bg_dark"], fg=COLORS["text_primary"]).pack(anchor="w", pady=(10, 8))
        tc = tk.Frame(self.table_frame, bg=COLORS["bg_light"],
                      highlightbackground=COLORS["border"], highlightthickness=1)
        tc.pack(fill="both", expand=True)
        hr = tk.Frame(tc, bg=COLORS["table_header"])
        hr.pack(fill="x")
        for t, w in [("  Roll No.", 12), ("Name", 18), ("Branch", 13),
                      ("Total", 8), ("Present", 9), ("Absent", 8), ("Percentage", 11)]:
            tk.Label(hr, text=t, font=FONTS["table_header"],
                     bg=COLORS["table_header"], fg=COLORS["primary_light"],
                     width=w, anchor="w", padx=6, pady=10).pack(side="left")
        lc = tk.Frame(tc, bg=COLORS["bg_dark"])
        lc.pack(fill="both", expand=True)
        sb = tk.Scrollbar(lc)
        sb.pack(side="right", fill="y")
        lb = tk.Listbox(lc, font=FONTS["table_body"], bg=COLORS["bg_dark"],
            fg=COLORS["text_primary"], selectbackground=COLORS["table_selected"],
            relief="flat", highlightthickness=0, yscrollcommand=sb.set, activestyle="none")
        lb.pack(fill="both", expand=True)
        sb.config(command=lb.yview)
        for i, r in enumerate(report):
            ps = f"{r['percentage']}%" if r['total_days'] > 0 else "N/A"
            line = (f"  {r['roll_no']:<14}{r['name']:<20}{r['branch']:<15}"
                    f"{r['total_days']:<10}{r['present_days']:<11}{r['absent_days']:<10}{ps}")
            lb.insert("end", line)
            bg = COLORS["table_row_even"] if i % 2 == 0 else COLORS["table_row_odd"]
            lb.itemconfig(i, bg=bg)
            if r['total_days'] > 0 and r['percentage'] < 75:
                lb.itemconfig(i, fg=COLORS["danger"])
            elif r['total_days'] > 0 and r['percentage'] >= 75:
                lb.itemconfig(i, fg=COLORS["success"])

    def _export(self):
        if not self.current_report:
            messagebox.showwarning("No Data", "Generate a report first!"); return
        os.makedirs(REPORTS_DIR, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        fn = f"report_{self.report_title.replace(' ', '_').replace('—', '-')}_{ts}.csv"
        fp = os.path.join(REPORTS_DIR, fn)
        try:
            with open(fp, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(["Roll No", "Name", "Branch", "Total", "Present", "Absent", "Percentage"])
                for r in self.current_report:
                    w.writerow([r["roll_no"], r["name"], r["branch"],
                                r["total_days"], r["present_days"], r["absent_days"], r["percentage"]])
            messagebox.showinfo("Exported", f"✅ Saved to:\n{fp}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed: {str(e)}")

"""
login.py — Premium Login Page with Role Selection
===================================================
Beautiful animated login with Student/Teacher toggle,
gradient accents, and smooth transitions.
Subject-wise teacher login with unique IDs per subject.
"""

import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
from gui.styles import COLORS, FONTS
from database.db_manager import authenticate_teacher, authenticate_student


class LoginPage(tk.Frame):
    """Premium login page with student/teacher role selection."""

    def __init__(self, parent, on_login_success):
        super().__init__(parent, bg=COLORS["login_bg"])
        self.on_login_success = on_login_success
        self.current_role = "teacher"  # Default
        self._create_widgets()

    def _create_widgets(self):
        # Center container
        self.center = tk.Frame(self, bg=COLORS["login_bg"])
        self.center.place(relx=0.5, rely=0.5, anchor="center")

        # ── App branding ──
        tk.Label(self.center, text="🎓", font=("Segoe UI", 52),
                 bg=COLORS["login_bg"], fg=COLORS["primary"]).pack(pady=(0, 5))

        tk.Label(self.center, text="Attendance Portal",
                 font=FONTS["login_title"],
                 bg=COLORS["login_bg"], fg=COLORS["text_primary"]).pack()

        tk.Label(self.center, text="Student Attendance Management System",
                 font=FONTS["login_subtitle"],
                 bg=COLORS["login_bg"], fg=COLORS["text_muted"]).pack(pady=(4, 25))

        # ── Login Card ──
        self.card = tk.Frame(self.center, bg=COLORS["login_card"],
                             highlightbackground=COLORS["border"], highlightthickness=1)
        self.card.pack(padx=40)

        # Top accent
        self.accent_bar = tk.Frame(self.card, bg=COLORS["primary"], height=4)
        self.accent_bar.pack(fill="x")

        card_inner = tk.Frame(self.card, bg=COLORS["login_card"])
        card_inner.pack(padx=35, pady=30)

        # ── Role Toggle ──
        tk.Label(card_inner, text="Select Your Role",
                 font=FONTS["body_bold"],
                 bg=COLORS["login_card"], fg=COLORS["text_secondary"]).pack(pady=(0, 10))

        toggle_frame = tk.Frame(card_inner, bg=COLORS["login_card"])
        toggle_frame.pack(pady=(0, 20))

        self.teacher_btn = tk.Label(
            toggle_frame, text="  👨‍🏫  Teacher  ",
            font=FONTS["body_bold"], padx=20, pady=8,
            bg=COLORS["primary"], fg="white", cursor="hand2"
        )
        self.teacher_btn.pack(side="left", padx=(0, 4))
        self.teacher_btn.bind("<Button-1>", lambda e: self._switch_role("teacher"))

        self.student_btn = tk.Label(
            toggle_frame, text="  👨‍🎓  Student  ",
            font=FONTS["body_bold"], padx=20, pady=8,
            bg=COLORS["bg_input"], fg=COLORS["text_secondary"], cursor="hand2"
        )
        self.student_btn.pack(side="left")
        self.student_btn.bind("<Button-1>", lambda e: self._switch_role("student"))

        # ── Form area (dynamic) ──
        self.form_frame = tk.Frame(card_inner, bg=COLORS["login_card"])
        self.form_frame.pack(fill="x")

        self._build_teacher_form()

        # ── Footer ──
        tk.Label(self.center, text="VIT Pune  •  BTEH Sem-2 Project",
                 font=FONTS["small"],
                 bg=COLORS["login_bg"], fg=COLORS["text_muted"]).pack(pady=(20, 0))

        # Subject-wise login credentials info
        info_frame = tk.Frame(self.center, bg=COLORS["login_bg"])
        info_frame.pack(pady=(12, 0))
        tk.Label(info_frame, text="Subject-Wise Faculty Logins:",
                 font=("Segoe UI Semibold", 9),
                 bg=COLORS["login_bg"], fg=COLORS["text_secondary"]).pack()

        creds_text = (
            "PY-TEACH / python123 (Snehal Khajurgi)  |  CAL-TEACH / calculus123 (Shital Sobale)\n"
            "AEM-TEACH / aem123 (Kalpesh Joshi)  |  DA-TEACH / data123 (Vinod Kimbahune)\n"
            "SRM-TEACH / srm123 (Jyoti Yadav)"
        )
        tk.Label(info_frame, text=creds_text,
                 font=("Segoe UI", 8),
                 bg=COLORS["login_bg"], fg=COLORS["text_muted"],
                 justify="center").pack(pady=(3, 0))

    def _switch_role(self, role):
        self.current_role = role
        for w in self.form_frame.winfo_children():
            w.destroy()

        if role == "teacher":
            self.teacher_btn.configure(bg=COLORS["primary"], fg="white")
            self.student_btn.configure(bg=COLORS["bg_input"], fg=COLORS["text_secondary"])
            self.accent_bar.configure(bg=COLORS["primary"])
            self._build_teacher_form()
        else:
            self.student_btn.configure(bg=COLORS["success"], fg="white")
            self.teacher_btn.configure(bg=COLORS["bg_input"], fg=COLORS["text_secondary"])
            self.accent_bar.configure(bg=COLORS["success"])
            self._build_student_form()

    def _build_teacher_form(self):
        f = self.form_frame

        # Info about subject-specific login
        info_lbl = tk.Label(f, text="🔑 Each subject has a unique Teacher ID",
                 font=("Segoe UI", 10),
                 bg=COLORS["login_card"], fg=COLORS["primary_light"])
        info_lbl.pack(pady=(0, 12))

        tk.Label(f, text="Teacher ID", font=FONTS["body_bold"],
                 bg=COLORS["login_card"], fg=COLORS["text_primary"]).pack(anchor="w", pady=(0, 4))
        self.teacher_id_entry = ctk.CTkEntry(
            f, font=("Segoe UI", 13), fg_color=COLORS["bg_input"],
            border_color=COLORS["border"], text_color=COLORS["text_primary"],
            placeholder_text="e.g., PY-TEACH, CAL-TEACH",
            placeholder_text_color=COLORS["text_muted"],
            corner_radius=8, height=42, width=320, border_width=1
        )
        self.teacher_id_entry.pack(pady=(0, 12))

        tk.Label(f, text="Password", font=FONTS["body_bold"],
                 bg=COLORS["login_card"], fg=COLORS["text_primary"]).pack(anchor="w", pady=(0, 4))
        self.password_entry = ctk.CTkEntry(
            f, font=("Segoe UI", 13), fg_color=COLORS["bg_input"],
            border_color=COLORS["border"], text_color=COLORS["text_primary"],
            placeholder_text="Enter password",
            placeholder_text_color=COLORS["text_muted"],
            corner_radius=8, height=42, width=320, border_width=1, show="●"
        )
        self.password_entry.pack(pady=(0, 20))
        self.password_entry.bind("<Return>", lambda e: self._login())

        ctk.CTkButton(
            f, text="🔐  Login as Teacher",
            font=("Segoe UI Semibold", 14),
            fg_color=COLORS["primary"], hover_color=COLORS["primary_hover"],
            corner_radius=8, width=320, height=44, command=self._login
        ).pack()

    def _build_student_form(self):
        f = self.form_frame

        tk.Label(f, text="Roll Number", font=FONTS["body_bold"],
                 bg=COLORS["login_card"], fg=COLORS["text_primary"]).pack(anchor="w", pady=(0, 4))
        self.student_roll_entry = ctk.CTkEntry(
            f, font=("Segoe UI", 13), fg_color=COLORS["bg_input"],
            border_color=COLORS["border"], text_color=COLORS["text_primary"],
            placeholder_text="e.g., BTEH-2026-001",
            placeholder_text_color=COLORS["text_muted"],
            corner_radius=8, height=42, width=320, border_width=1
        )
        self.student_roll_entry.pack(pady=(0, 12))

        tk.Label(f, text="Full Name", font=FONTS["body_bold"],
                 bg=COLORS["login_card"], fg=COLORS["text_primary"]).pack(anchor="w", pady=(0, 4))
        self.student_name_entry = ctk.CTkEntry(
            f, font=("Segoe UI", 13), fg_color=COLORS["bg_input"],
            border_color=COLORS["border"], text_color=COLORS["text_primary"],
            placeholder_text="Enter your full name",
            placeholder_text_color=COLORS["text_muted"],
            corner_radius=8, height=42, width=320, border_width=1
        )
        self.student_name_entry.pack(pady=(0, 20))
        self.student_name_entry.bind("<Return>", lambda e: self._login())

        ctk.CTkButton(
            f, text="📚  Login as Student",
            font=("Segoe UI Semibold", 14),
            fg_color=COLORS["success"], hover_color=COLORS["success_hover"],
            corner_radius=8, width=320, height=44, command=self._login
        ).pack()

    def _login(self):
        if self.current_role == "teacher":
            tid = self.teacher_id_entry.get().strip()
            pwd = self.password_entry.get().strip()
            if not tid or not pwd:
                messagebox.showwarning("Missing Fields", "Please enter Teacher ID and Password!")
                return
            teacher = authenticate_teacher(tid, pwd)
            if teacher:
                self.on_login_success("teacher", {
                    "id": teacher[0], "teacher_id": teacher[1], "name": teacher[2],
                    "subject_id": teacher[3], "subject_name": teacher[4]
                })
            else:
                messagebox.showerror("Login Failed", "Invalid Teacher ID or Password!")
        else:
            roll = self.student_roll_entry.get().strip()
            name = self.student_name_entry.get().strip()
            if not roll or not name:
                messagebox.showwarning("Missing Fields", "Please enter Roll Number and Name!")
                return
            student = authenticate_student(roll, name)
            if student:
                self.on_login_success("student", {
                    "id": student[0], "roll_no": student[1],
                    "name": student[2], "branch": student[3]
                })
            else:
                messagebox.showerror("Login Failed",
                    "Student not found!\nMake sure your Roll Number and Name match the records.")

"""
student_dashboard.py — Student-Only Dashboard (Read-Only)
==========================================================
Shows the logged-in student's attendance with subject-wise breakdown
for all five subjects: Python, Calculus, AEM, Data Analysis, SRM-2.
No edit/delete/add capabilities — view only.
"""

import tkinter as tk
from gui.styles import COLORS, FONTS
from database.db_manager import (
    get_attendance_percentage, get_attendance_by_roll_no,
    get_subject_wise_attendance
)


class StudentDashboardFrame(tk.Frame):
    """Read-only attendance dashboard for a logged-in student."""

    def __init__(self, parent, student_info):
        super().__init__(parent, bg=COLORS["bg_dark"])
        self.student = student_info
        self._create_widgets()

    def _create_widgets(self):
        canvas = tk.Canvas(self, bg=COLORS["bg_dark"], highlightthickness=0)
        sb = tk.Scrollbar(self, orient="vertical", command=canvas.yview)
        content = tk.Frame(canvas, bg=COLORS["bg_dark"])
        content.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=content, anchor="nw", tags="c")
        canvas.configure(yscrollcommand=sb.set)
        def occ(event): canvas.itemconfig("c", width=event.width)
        canvas.bind("<Configure>", occ)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        canvas.bind_all("<MouseWheel>",
            lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        roll = self.student["roll_no"]
        name = self.student["name"]
        branch = self.student["branch"]
        stats = get_attendance_percentage(roll)
        subj_stats = get_subject_wise_attendance(roll)
        records = get_attendance_by_roll_no(roll)

        # ── Welcome Header ──
        hdr = tk.Frame(content, bg=COLORS["bg_medium"])
        hdr.pack(fill="x", padx=25, pady=(25, 0))
        hi = tk.Frame(hdr, bg=COLORS["bg_medium"])
        hi.pack(fill="x", padx=25, pady=20)

        from datetime import datetime
        hour = datetime.now().hour
        greet = "Good Morning" if hour < 12 else ("Good Afternoon" if hour < 17 else "Good Evening")
        tk.Label(hi, text=f"👋 {greet}, {name}!",
                 font=FONTS["heading"], bg=COLORS["bg_medium"],
                 fg=COLORS["text_primary"]).pack(anchor="w")
        dr = tk.Frame(hi, bg=COLORS["bg_medium"])
        dr.pack(anchor="w", pady=(6, 0))
        tk.Label(dr, text=f"  {roll}  ", font=FONTS["badge"],
                 bg=COLORS["primary"], fg="white", padx=6, pady=2).pack(side="left", padx=(0, 8))
        tk.Label(dr, text=f"  {branch}  ", font=FONTS["badge"],
                 bg=COLORS["bg_input"], fg=COLORS["text_secondary"],
                 padx=6, pady=2).pack(side="left")

        # ── Stats Cards ──
        if stats:
            pct = stats["percentage"]
            pc = COLORS["success"] if pct >= 75 else (COLORS["warning"] if pct >= 50 else COLORS["danger"])

            sf = tk.Frame(content, bg=COLORS["bg_dark"])
            sf.pack(fill="x", padx=25, pady=(20, 0))
            for i in range(4):
                sf.grid_columnconfigure(i, weight=1, uniform="sc")

            cards = [
                ("Attendance", f"{pct}%", "📊", pc),
                ("Present", str(stats["present_days"]), "✅", COLORS["success"]),
                ("Absent", str(stats["absent_days"]), "❌", COLORS["danger"]),
                ("Total Classes", str(stats["total_days"]), "📋", COLORS["info"]),
            ]
            for i, (lb, vl, ic, cl) in enumerate(cards):
                cd = tk.Frame(sf, bg=COLORS["bg_light"],
                              highlightbackground=COLORS["border"], highlightthickness=1)
                cd.grid(row=0, column=i, padx=(0, 12) if i < 3 else 0, sticky="nsew")
                tk.Frame(cd, bg=cl, height=3).pack(fill="x")
                cdi = tk.Frame(cd, bg=COLORS["bg_light"])
                cdi.pack(fill="both", expand=True, padx=18, pady=15)
                tr = tk.Frame(cdi, bg=COLORS["bg_light"])
                tr.pack(fill="x")
                tk.Label(tr, text=ic, font=("Segoe UI", 20),
                         bg=COLORS["bg_light"], fg=cl).pack(side="left")
                tk.Label(tr, text=lb, font=FONTS["card_label"],
                         bg=COLORS["bg_light"], fg=COLORS["text_secondary"]).pack(side="right")
                tk.Label(cdi, text=vl, font=FONTS["card_value"],
                         bg=COLORS["bg_light"], fg=cl, anchor="w").pack(anchor="w", pady=(8, 0))

            # Attendance bar
            bar_card = tk.Frame(content, bg=COLORS["bg_light"],
                                highlightbackground=COLORS["border"], highlightthickness=1)
            bar_card.pack(fill="x", padx=25, pady=(15, 0))
            bci = tk.Frame(bar_card, bg=COLORS["bg_light"])
            bci.pack(fill="both", padx=22, pady=18)
            bt = tk.Frame(bci, bg=COLORS["bg_light"])
            bt.pack(fill="x")
            tk.Label(bt, text="📊 Overall Attendance Rate", font=FONTS["subheading"],
                     bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(side="left")
            tk.Label(bt, text=f"{pct}%", font=("Segoe UI Semibold", 18),
                     bg=COLORS["bg_light"], fg=pc).pack(side="right")
            bbg = tk.Frame(bci, bg=COLORS["bg_input"], height=14)
            bbg.pack(fill="x", pady=(12, 0))
            bbg.pack_propagate(False)
            bf = tk.Frame(bbg, bg=pc, height=14)
            bf.place(relwidth=max(pct / 100, 0.01), relheight=1)

            # Warning if below 75%
            if pct < 75:
                wf = tk.Frame(bci, bg=COLORS["bg_light"])
                wf.pack(fill="x", pady=(8, 0))
                tk.Label(wf, text=f"⚠️  Your attendance is below 75%. You need {75 - pct:.1f}% more to meet the requirement.",
                         font=FONTS["small_bold"], bg=COLORS["bg_light"],
                         fg=COLORS["danger"]).pack(anchor="w")

        # ── Subject-wise Attendance (All 5 subjects) ──
        tk.Label(content, text="📚  Subject-wise Attendance",
                 font=FONTS["subheading"], bg=COLORS["bg_dark"],
                 fg=COLORS["text_primary"]).pack(anchor="w", padx=25, pady=(20, 8))

        if subj_stats:
            sfc = tk.Frame(content, bg=COLORS["bg_dark"])
            sfc.pack(fill="x", padx=25)
            cols = min(len(subj_stats), 5)
            for i in range(cols):
                sfc.grid_columnconfigure(i, weight=1, uniform="subj")
            for i, ss in enumerate(subj_stats[:5]):
                spc = COLORS["success"] if ss["percentage"] >= 75 else (
                    COLORS["warning"] if ss["percentage"] >= 50 else COLORS["danger"])
                sc = tk.Frame(sfc, bg=COLORS["bg_light"],
                              highlightbackground=COLORS["border"], highlightthickness=1)
                sc.grid(row=0, column=i, padx=(0, 8) if i < cols-1 else 0, sticky="nsew")
                tk.Frame(sc, bg=spc, height=3).pack(fill="x")
                sci = tk.Frame(sc, bg=COLORS["bg_light"])
                sci.pack(padx=12, pady=12)
                tk.Label(sci, text=ss["subject"], font=FONTS["body_bold"],
                         bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack()

                # Large percentage display
                if ss["total"] > 0:
                    tk.Label(sci, text=f"{ss['percentage']}%",
                             font=("Segoe UI", 22, "bold"),
                             bg=COLORS["bg_light"], fg=spc).pack(pady=(4, 2))
                else:
                    tk.Label(sci, text="N/A",
                             font=("Segoe UI", 22, "bold"),
                             bg=COLORS["bg_light"], fg=COLORS["text_muted"]).pack(pady=(4, 2))

                tk.Label(sci, text=f"P:{ss['present']}  A:{ss['absent']}  T:{ss['total']}",
                         font=FONTS["small"], bg=COLORS["bg_light"],
                         fg=COLORS["text_muted"]).pack()

                # Mini progress bar for each subject
                mini_bar_bg = tk.Frame(sci, bg=COLORS["bg_input"], height=6)
                mini_bar_bg.pack(fill="x", pady=(6, 0))
                mini_bar_bg.pack_propagate(False)
                if ss["total"] > 0:
                    mini_bar_fill = tk.Frame(mini_bar_bg, bg=spc, height=6)
                    mini_bar_fill.place(relwidth=max(ss["percentage"] / 100, 0.01), relheight=1)

            # Extra subjects on next row (if > 5)
            if len(subj_stats) > 5:
                for i in range(min(len(subj_stats) - 5, 5)):
                    sfc.grid_columnconfigure(i, weight=1, uniform="subj")
                for i, ss in enumerate(subj_stats[5:10]):
                    spc = COLORS["success"] if ss["percentage"] >= 75 else (
                        COLORS["warning"] if ss["percentage"] >= 50 else COLORS["danger"])
                    sc = tk.Frame(sfc, bg=COLORS["bg_light"],
                                  highlightbackground=COLORS["border"], highlightthickness=1)
                    sc.grid(row=1, column=i, padx=(0, 8) if i < min(len(subj_stats)-5, 5)-1 else 0,
                            pady=(8, 0), sticky="nsew")
                    tk.Frame(sc, bg=spc, height=3).pack(fill="x")
                    sci = tk.Frame(sc, bg=COLORS["bg_light"])
                    sci.pack(padx=12, pady=12)
                    tk.Label(sci, text=ss["subject"], font=FONTS["body_bold"],
                             bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack()
                    if ss["total"] > 0:
                        tk.Label(sci, text=f"{ss['percentage']}%",
                                 font=("Segoe UI", 22, "bold"),
                                 bg=COLORS["bg_light"], fg=spc).pack(pady=(4, 2))
                    else:
                        tk.Label(sci, text="N/A",
                                 font=("Segoe UI", 22, "bold"),
                                 bg=COLORS["bg_light"], fg=COLORS["text_muted"]).pack(pady=(4, 2))
                    tk.Label(sci, text=f"P:{ss['present']}  A:{ss['absent']}  T:{ss['total']}",
                             font=FONTS["small"], bg=COLORS["bg_light"],
                             fg=COLORS["text_muted"]).pack()
                    mini_bar_bg = tk.Frame(sci, bg=COLORS["bg_input"], height=6)
                    mini_bar_bg.pack(fill="x", pady=(6, 0))
                    mini_bar_bg.pack_propagate(False)
                    if ss["total"] > 0:
                        mini_bar_fill = tk.Frame(mini_bar_bg, bg=spc, height=6)
                        mini_bar_fill.place(relwidth=max(ss["percentage"] / 100, 0.01), relheight=1)
        else:
            tk.Label(content, text="No subject attendance data yet.",
                     font=FONTS["body"], bg=COLORS["bg_dark"],
                     fg=COLORS["text_secondary"]).pack(anchor="w", padx=25)

        # ── Attendance History ──
        tk.Label(content, text="📋  Recent Attendance History",
                 font=FONTS["subheading"], bg=COLORS["bg_dark"],
                 fg=COLORS["text_primary"]).pack(anchor="w", padx=25, pady=(20, 8))

        if not records:
            tk.Label(content, text="No attendance records yet.",
                     font=FONTS["body"], bg=COLORS["bg_dark"],
                     fg=COLORS["text_secondary"]).pack(anchor="w", padx=25, pady=(0, 25))
        else:
            tc = tk.Frame(content, bg=COLORS["bg_light"],
                          highlightbackground=COLORS["border"], highlightthickness=1)
            tc.pack(fill="x", padx=25, pady=(0, 25))
            hr = tk.Frame(tc, bg=COLORS["table_header"])
            hr.pack(fill="x")
            for t, w in [("  #", 5), ("Date", 18), ("Subject", 18), ("Status", 15)]:
                tk.Label(hr, text=t, font=FONTS["table_header"],
                         bg=COLORS["table_header"], fg=COLORS["primary_light"],
                         width=w, anchor="w", padx=8, pady=10).pack(side="left")
            for i, (date, status, subject) in enumerate(records[:50]):
                rbg = COLORS["table_row_even"] if i % 2 == 0 else COLORS["table_row_odd"]
                row = tk.Frame(tc, bg=rbg)
                row.pack(fill="x")
                icon = "✅" if status == "Present" else "❌"
                fc = COLORS["text_primary"] if status == "Present" else COLORS["danger"]
                tk.Label(row, text=f"  {i+1}", font=FONTS["table_body"], bg=rbg,
                         fg=COLORS["text_muted"], width=5, anchor="w", padx=8, pady=7).pack(side="left")
                tk.Label(row, text=date, font=FONTS["table_body"], bg=rbg,
                         fg=fc, width=18, anchor="w", padx=8).pack(side="left")
                tk.Label(row, text=subject, font=FONTS["table_body"], bg=rbg,
                         fg=COLORS["text_secondary"], width=18, anchor="w", padx=8).pack(side="left")
                tk.Label(row, text=f"{icon}  {status}", font=FONTS["table_body"], bg=rbg,
                         fg=fc, width=15, anchor="w", padx=8).pack(side="left")

        # No-data fallback
        if not stats:
            nd = tk.Frame(content, bg=COLORS["bg_light"],
                          highlightbackground=COLORS["border"], highlightthickness=1)
            nd.pack(fill="x", padx=25, pady=(20, 25))
            ndi = tk.Frame(nd, bg=COLORS["bg_light"])
            ndi.pack(padx=30, pady=30)
            tk.Label(ndi, text="📭", font=("Segoe UI", 40),
                     bg=COLORS["bg_light"]).pack()
            tk.Label(ndi, text="No Attendance Data Yet",
                     font=FONTS["subheading"], bg=COLORS["bg_light"],
                     fg=COLORS["text_primary"]).pack(pady=(8, 4))
            tk.Label(ndi, text="Your teacher hasn't marked any attendance yet.\nCheck back later!",
                     font=FONTS["body"], bg=COLORS["bg_light"],
                     fg=COLORS["text_secondary"]).pack()

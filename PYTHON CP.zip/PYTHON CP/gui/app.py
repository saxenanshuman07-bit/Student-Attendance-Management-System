"""
app.py — Main Application with Role-Based Navigation
======================================================
Manages sidebar, content area, and role-based page routing.
Teacher gets subject-scoped access; Student gets read-only dashboard.
"""

import tkinter as tk
import os
from datetime import datetime
from PIL import Image, ImageTk
from gui.styles import COLORS, FONTS, SIZES, TEACHER_MENU_ITEMS, STUDENT_MENU_ITEMS
from gui.add_student import AddStudentFrame
from gui.mark_attendance import MarkAttendanceFrame
from gui.view_records import ViewRecordsFrame
from gui.search_student import SearchStudentFrame
from gui.attendance_report import AttendanceReportFrame
from gui.student_dashboard import StudentDashboardFrame
from database.db_manager import get_all_students, get_all_attendance_records

# Path to the VIT Pune logo
_LOGO_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          "vit logo1.jpg")


class AttendanceApp:
    """Main application with role-based sidebar and content management."""

    def __init__(self, root, role, user_info, on_logout):
        self.root = root
        self.role = role
        self.user = user_info
        self.on_logout = on_logout
        self.active_page = "dashboard"
        self.menu_buttons = {}
        self.hover_indicators = {}

        # Extract subject info for teacher
        self.subject_id = user_info.get("subject_id") if role == "teacher" else None
        self.subject_name = user_info.get("subject_name", "General") if role == "teacher" else None

        # Clear root
        for w in self.root.winfo_children():
            w.destroy()

        self.root.configure(bg=COLORS["bg_dark"])
        self._create_layout()
        self._show_page("dashboard")

    def _create_layout(self):
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(1, weight=1)

        # Sidebar
        self.sidebar = tk.Frame(self.root, bg=COLORS["sidebar_bg"],
                                width=SIZES["sidebar_width"], highlightthickness=0)
        self.sidebar.grid(row=0, column=0, sticky="nsw")
        self.sidebar.grid_propagate(False)
        tk.Frame(self.sidebar, bg=COLORS["primary"], width=3).place(x=0, y=0, relheight=1)
        self._build_sidebar()

        # Divider
        tk.Frame(self.root, bg=COLORS["border"], width=1).grid(row=0, column=0, sticky="nse")

        # Content
        self.content_area = tk.Frame(self.root, bg=COLORS["bg_dark"])
        self.content_area.grid(row=0, column=1, sticky="nsew")

    def _build_sidebar(self):
        # Header
        hdr = tk.Frame(self.sidebar, bg=COLORS["sidebar_bg"])
        hdr.pack(fill="x", padx=15, pady=(20, 0))

        # VIT Pune Logo
        try:
            logo_img = Image.open(_LOGO_PATH)
            logo_img = logo_img.resize((80, 80), Image.LANCZOS)
            self._logo_photo = ImageTk.PhotoImage(logo_img)
            tk.Label(hdr, image=self._logo_photo,
                     bg=COLORS["sidebar_bg"]).pack(pady=(5, 8))
        except Exception:
            # Fallback to emoji if logo file can't be loaded
            tk.Label(hdr, text="🎓", font=("Segoe UI", 36),
                     bg=COLORS["sidebar_bg"], fg=COLORS["primary"]).pack(pady=(5, 8))

        tk.Label(hdr, text="Student Attendance", font=("Segoe UI Semibold", 14),
                 bg=COLORS["sidebar_bg"], fg=COLORS["text_primary"]).pack()
        tk.Label(hdr, text="System", font=("Segoe UI", 11),
                 bg=COLORS["sidebar_bg"], fg=COLORS["primary_light"]).pack(pady=(0, 5))

        # User info
        user_frame = tk.Frame(self.sidebar, bg=COLORS["sidebar_bg"])
        user_frame.pack(fill="x", padx=18, pady=(10, 0))
        role_icon = "👨‍🏫" if self.role == "teacher" else "👨‍🎓"
        role_label = "Teacher" if self.role == "teacher" else "Student"
        tk.Label(user_frame, text=f"{role_icon}  {self.user.get('name', '')}",
                 font=FONTS["small_bold"], bg=COLORS["sidebar_bg"],
                 fg=COLORS["text_primary"], anchor="w").pack(fill="x")
        role_badge_color = COLORS["primary"] if self.role == "teacher" else COLORS["success"]
        rb = tk.Label(user_frame, text=f"  {role_label}  ", font=FONTS["badge"],
                      bg=role_badge_color, fg="white", padx=4, pady=1)
        rb.pack(anchor="w", pady=(4, 0))

        # Subject badge for teacher
        if self.role == "teacher" and self.subject_name:
            subj_badge = tk.Label(user_frame, text=f"  📚 {self.subject_name}  ",
                                  font=FONTS["badge"],
                                  bg=COLORS["warning"], fg="#1A1A30", padx=4, pady=1)
            subj_badge.pack(anchor="w", pady=(4, 0))

        # Separator
        sf = tk.Frame(self.sidebar, bg=COLORS["sidebar_bg"])
        sf.pack(fill="x", padx=20, pady=(12, 8))
        tk.Frame(sf, bg=COLORS["border"], height=1).pack(fill="x")

        # Nav label
        tk.Label(self.sidebar, text="  NAVIGATION", font=("Segoe UI Semibold", 9),
                 bg=COLORS["sidebar_bg"], fg=COLORS["text_muted"],
                 anchor="w").pack(fill="x", padx=18, pady=(8, 4))

        # Menu items
        items = TEACHER_MENU_ITEMS if self.role == "teacher" else STUDENT_MENU_ITEMS
        for item in items:
            self._create_menu_btn(item)

        # Footer
        footer = tk.Frame(self.sidebar, bg=COLORS["sidebar_bg"])
        footer.pack(side="bottom", fill="x", padx=15, pady=15)
        tk.Frame(footer, bg=COLORS["border"], height=1).pack(fill="x", pady=(0, 10))
        tk.Label(footer, text="VIT Pune", font=("Segoe UI Semibold", 10),
                 bg=COLORS["sidebar_bg"], fg=COLORS["text_secondary"]).pack()
        tk.Label(footer, text="BTEH Sem-2 Project", font=("Segoe UI", 9),
                 bg=COLORS["sidebar_bg"], fg=COLORS["text_muted"]).pack(pady=(2, 0))

    def _create_menu_btn(self, item):
        container = tk.Frame(self.sidebar, bg=COLORS["sidebar_bg"])
        container.pack(fill="x", padx=10, pady=2)
        indicator = tk.Frame(container, bg=COLORS["sidebar_bg"], width=4)
        indicator.pack(side="left", fill="y")
        self.hover_indicators[item["key"]] = indicator
        btn = tk.Label(container, text=item["label"], font=FONTS["sidebar"],
            bg=COLORS["sidebar_bg"], fg=COLORS["text_secondary"],
            anchor="w", padx=12, pady=10, cursor="hand2")
        btn.pack(side="left", fill="x", expand=True)
        self.menu_buttons[item["key"]] = (btn, container)
        for w in (btn, container):
            w.bind("<Button-1>", lambda e, k=item["key"]: self._handle_nav(k))
            w.bind("<Enter>", lambda e, k=item["key"]: self._on_hover(k))
            w.bind("<Leave>", lambda e, k=item["key"]: self._on_leave(k))

    def _handle_nav(self, key):
        if key == "logout":
            self.on_logout()
        else:
            self._show_page(key)

    def _on_hover(self, key):
        if key != self.active_page and key != "logout":
            b, c = self.menu_buttons[key]
            c.configure(bg=COLORS["sidebar_hover"])
            b.configure(bg=COLORS["sidebar_hover"], fg=COLORS["text_primary"])
            self.hover_indicators[key].configure(bg=COLORS["primary_light"])
        elif key == "logout":
            b, c = self.menu_buttons[key]
            c.configure(bg=COLORS["danger_bg"])
            b.configure(bg=COLORS["danger_bg"], fg=COLORS["danger"])

    def _on_leave(self, key):
        if key != self.active_page:
            b, c = self.menu_buttons[key]
            c.configure(bg=COLORS["sidebar_bg"])
            b.configure(bg=COLORS["sidebar_bg"],
                        fg=COLORS["text_secondary"] if key != "logout" else COLORS["text_secondary"])
            self.hover_indicators[key].configure(bg=COLORS["sidebar_bg"])

    def _update_sidebar(self):
        for key, (btn, container) in self.menu_buttons.items():
            if key == "logout":
                continue
            if key == self.active_page:
                container.configure(bg=COLORS["sidebar_hover"])
                btn.configure(bg=COLORS["sidebar_hover"], fg=COLORS["primary_light"],
                              font=FONTS["sidebar_active"])
                self.hover_indicators[key].configure(bg=COLORS["primary"])
            else:
                container.configure(bg=COLORS["sidebar_bg"])
                btn.configure(bg=COLORS["sidebar_bg"], fg=COLORS["text_secondary"],
                              font=FONTS["sidebar"])
                self.hover_indicators[key].configure(bg=COLORS["sidebar_bg"])

    def _show_page(self, key):
        self.active_page = key
        self._update_sidebar()
        for w in self.content_area.winfo_children():
            w.destroy()

        if self.role == "student":
            if key == "dashboard":
                f = StudentDashboardFrame(self.content_area, self.user)
                f.pack(fill="both", expand=True)
            elif key == "my_attendance":
                f = StudentDashboardFrame(self.content_area, self.user)
                f.pack(fill="both", expand=True)
        else:  # teacher
            if key == "dashboard":
                self._show_teacher_dashboard()
            elif key == "add_student":
                AddStudentFrame(self.content_area).pack(fill="both", expand=True)
            elif key == "mark_attendance":
                MarkAttendanceFrame(self.content_area,
                                    subject_id=self.subject_id,
                                    subject_name=self.subject_name).pack(fill="both", expand=True)
            elif key == "view_records":
                ViewRecordsFrame(self.content_area,
                                 subject_id=self.subject_id).pack(fill="both", expand=True)
            elif key == "search_student":
                SearchStudentFrame(self.content_area).pack(fill="both", expand=True)
            elif key == "reports":
                AttendanceReportFrame(self.content_area,
                                      subject_id=self.subject_id,
                                      subject_name=self.subject_name).pack(fill="both", expand=True)

    def _show_teacher_dashboard(self):
        canvas = tk.Canvas(self.content_area, bg=COLORS["bg_dark"], highlightthickness=0)
        sb = tk.Scrollbar(self.content_area, orient="vertical", command=canvas.yview)
        dash = tk.Frame(canvas, bg=COLORS["bg_dark"])
        dash.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=dash, anchor="nw", tags="dw")
        canvas.configure(yscrollcommand=sb.set)
        def occ(e): canvas.itemconfig("dw", width=e.width)
        canvas.bind("<Configure>", occ)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        canvas.bind_all("<MouseWheel>",
            lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        # Header
        hbg = tk.Frame(dash, bg=COLORS["bg_medium"])
        hbg.pack(fill="x", padx=25, pady=(25, 0))
        hi = tk.Frame(hbg, bg=COLORS["bg_medium"])
        hi.pack(fill="x", padx=25, pady=20)
        hour = datetime.now().hour
        greet = "Good Morning" if hour < 12 else ("Good Afternoon" if hour < 17 else "Good Evening")
        tk.Label(hi, text=f"👋 {greet}, {self.user.get('name', 'Teacher')}!",
                 font=("Segoe UI", 14), bg=COLORS["bg_medium"],
                 fg=COLORS["text_secondary"]).pack(anchor="w")
        tk.Label(hi, text=f"Teacher Dashboard — {self.subject_name}", font=FONTS["heading"],
                 bg=COLORS["bg_medium"], fg=COLORS["text_primary"]).pack(anchor="w", pady=(4, 0))
        tk.Label(hi, text=f"Subject: {self.subject_name}  •  VIT Pune",
                 font=FONTS["small"], bg=COLORS["bg_medium"],
                 fg=COLORS["text_muted"]).pack(anchor="w", pady=(4, 0))

        # Stats — filtered by this teacher's subject
        students = get_all_students()
        records = get_all_attendance_records(subject_id=self.subject_id)
        ts = len(students)
        tr = len(records)
        pc = sum(1 for r in records if r[4] == "Present")
        ac = tr - pc
        avg = round((pc / tr * 100), 1) if tr > 0 else 0

        sf = tk.Frame(dash, bg=COLORS["bg_dark"])
        sf.pack(fill="x", padx=25, pady=(20, 0))
        for i in range(4):
            sf.grid_columnconfigure(i, weight=1, uniform="cards")
        for i, (lb, vl, ic, acl, bg) in enumerate([
            ("Total Students", str(ts), "👨‍🎓", COLORS["primary"], COLORS["bg_light"]),
            ("Total Records", str(tr), "📋", COLORS["info"], COLORS["info_bg"]),
            ("Present Count", str(pc), "✅", COLORS["success"], COLORS["success_bg"]),
            ("Absent Count", str(ac), "❌", COLORS["danger"], COLORS["danger_bg"])]):
            cd = tk.Frame(sf, bg=COLORS["bg_light"],
                          highlightbackground=COLORS["border"], highlightthickness=1)
            cd.grid(row=0, column=i, padx=(0, 12) if i < 3 else 0, sticky="nsew")
            tk.Frame(cd, bg=acl, height=3).pack(fill="x")
            cdi = tk.Frame(cd, bg=COLORS["bg_light"])
            cdi.pack(fill="both", expand=True, padx=18, pady=15)
            trow = tk.Frame(cdi, bg=COLORS["bg_light"])
            trow.pack(fill="x")
            tk.Label(trow, text=ic, font=("Segoe UI", 20),
                     bg=COLORS["bg_light"], fg=acl).pack(side="left")
            tk.Label(trow, text=lb, font=FONTS["card_label"],
                     bg=COLORS["bg_light"], fg=COLORS["text_secondary"]).pack(side="right")
            tk.Label(cdi, text=vl, font=FONTS["card_value"],
                     bg=COLORS["bg_light"], fg=acl, anchor="w").pack(anchor="w", pady=(8, 0))

        # Attendance Rate Bar
        rc = tk.Frame(dash, bg=COLORS["bg_light"],
                      highlightbackground=COLORS["border"], highlightthickness=1)
        rc.pack(fill="x", padx=25, pady=(15, 0))
        rci = tk.Frame(rc, bg=COLORS["bg_light"])
        rci.pack(fill="both", padx=22, pady=18)
        rt = tk.Frame(rci, bg=COLORS["bg_light"])
        rt.pack(fill="x")
        tk.Label(rt, text=f"📊 {self.subject_name} — Attendance Rate", font=FONTS["subheading"],
                 bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(side="left")
        bc = COLORS["success"] if avg >= 75 else (COLORS["warning"] if avg >= 50 else COLORS["danger"])
        tk.Label(rt, text=f"{avg}%", font=("Segoe UI Semibold", 18),
                 bg=COLORS["bg_light"], fg=bc).pack(side="right")
        bbg = tk.Frame(rci, bg=COLORS["bg_input"], height=14)
        bbg.pack(fill="x", pady=(12, 0))
        bbg.pack_propagate(False)
        bfl = tk.Frame(bbg, bg=bc, height=14)
        bfl.place(relwidth=max(avg / 100, 0.01), relheight=1)
        bi = tk.Frame(rci, bg=COLORS["bg_light"])
        bi.pack(fill="x", pady=(8, 0))
        tk.Label(bi, text=f"Present: {pc}", font=FONTS["small"],
                 bg=COLORS["bg_light"], fg=COLORS["success"]).pack(side="left")
        tk.Label(bi, text=f"Absent: {ac}", font=FONTS["small"],
                 bg=COLORS["bg_light"], fg=COLORS["danger"]).pack(side="left", padx=(20, 0))
        tk.Label(bi, text=f"Total: {tr}", font=FONTS["small"],
                 bg=COLORS["bg_light"], fg=COLORS["text_muted"]).pack(side="right")

        # Quick Actions
        qa = tk.Frame(dash, bg=COLORS["bg_dark"])
        qa.pack(fill="x", padx=25, pady=(20, 0))
        tk.Label(qa, text="⚡ Quick Actions", font=FONTS["subheading"],
                 bg=COLORS["bg_dark"], fg=COLORS["text_primary"]).pack(anchor="w", pady=(0, 12))
        bc2 = tk.Frame(qa, bg=COLORS["bg_dark"])
        bc2.pack(fill="x")
        for txt, key, cl, hcl in [
            ("➕  Add Student", "add_student", COLORS["primary"], COLORS["primary_hover"]),
            (f"📋  Mark {self.subject_name}", "mark_attendance", COLORS["success"], COLORS["success_hover"]),
            ("🔍  Search Student", "search_student", COLORS["warning"], "#E6A030"),
            ("📈  Generate Report", "reports", COLORS["info"], "#2090E0")]:
            b = tk.Label(bc2, text=txt, font=FONTS["button"], bg=cl, fg="white",
                         padx=20, pady=12, cursor="hand2")
            b.pack(side="left", padx=(0, 12))
            b.bind("<Button-1>", lambda e, k=key: self._show_page(k))
            b.bind("<Enter>", lambda e, btn=b, h=hcl: btn.configure(bg=h))
            b.bind("<Leave>", lambda e, btn=b, c=cl: btn.configure(bg=c))

        # System Info
        info_f = tk.Frame(dash, bg=COLORS["bg_dark"])
        info_f.pack(fill="x", padx=25, pady=(20, 25))
        ic = tk.Frame(info_f, bg=COLORS["bg_light"],
                      highlightbackground=COLORS["border"], highlightthickness=1)
        ic.pack(fill="x")
        ici = tk.Frame(ic, bg=COLORS["bg_light"])
        ici.pack(fill="x", padx=22, pady=15)
        tk.Label(ici, text="ℹ️  System Information", font=FONTS["body_bold"],
                 bg=COLORS["bg_light"], fg=COLORS["text_primary"]).pack(anchor="w")
        it = (f"📅  {datetime.now().strftime('%d %B %Y')}  |  "
              f"🕐  {datetime.now().strftime('%I:%M %p')}  |  "
              f"📚  Subject: {self.subject_name}  |  "
              f"🏫  VIT Pune")
        tk.Label(ici, text=it, font=FONTS["small"],
                 bg=COLORS["bg_light"], fg=COLORS["text_muted"]).pack(anchor="w", pady=(5, 0))
